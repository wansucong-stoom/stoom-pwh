<a id="core-patches-table-layout-and-source-ownership"></a>
# 코어 패치: 표 조판과 원문 소유 범위

이 디렉터리는 rhwp 0.8.7에 적용한 변경을 검토할 수 있도록 보존합니다. Pwh의 Studio·클라이언트 패치와 구분되는 **조판 코어 변경**입니다. 문서를 읽을 때의 배치 보완은 원문의 텍스트·셀 높이·글꼴·여백을 유지합니다. 명시적인 크기 조절이나 그림 이동 같은 편집 명령은 각 패치의 범위에 따라 저장 치수를 갱신합니다. 넘친 글자를 잘라 가리거나 줄 간격을 압축하지 않으며, 문서 전체에 `reflowLinesegs` 복구를 호출하지 않습니다.

개별 패치를 설계·검증할 때 따르는 [공통 조판 소유권 규칙](LAYOUT-OWNERSHIP-RULES.md)을 별도로 관리합니다. 원문 앵커와 표시 순서, 물리 프레임과 내용 커서, 여백·편집 상태의 기준을 설명하며, 각 규칙의 실제 적용 범위와 배포 상태는 아래 패치별 기록을 따릅니다.

## 공통 편집기의 줄 간격 측정 재사용

scripts/patch-canvas-metric-reuse.mjs는 코어 패치와 별개로 rhwp Studio 유래의 Canvas 측정 준비를 보완합니다. src/canvas-metric-mutations.mjs가 줄 간격 변경을 분류하고, 기존 변이 메서드 레지스트리·복원 경로·변경 이벤트가 나머지 목록 갱신을 담당합니다. 글꼴 세대 변경·문서 교체·준비 실패에는 이전 결과를 사용하지 않습니다. 기존 글자별 폭 캐시와 비동기 세대 검사를 유지하며 공통·Desktop을 같은 입력으로 재현 빌드합니다. [검증 범위](../verification/PARAGRAPH-SPACING-PERFORMANCE.md)

<a id="cause-and-scope"></a>
## 원인과 적용 범위

### r33 공통 코어의 101번 구역 편집 패치

[101번 패치](rhwp-0.8.7-editable-section-break.patch)는 본문의 커서 위치에서 실제 구역을 분리합니다. 새 구역은 활성 용지·여백·단 설정을 상속하고 쪽 번호를 이어갑니다. 쪽과 단이 문서 모델의 구역 목록을 공유하므로 구역별 설정, 조판, HWPX 직렬화가 같은 경계를 사용합니다. 구역 경계에서 Backspace나 Delete로 합칠 때는 앞 구역의 배치를 따릅니다. [편집기 연결](../../scripts/patch-section-edit.mjs)은 이 작업을 기존 실행 취소에 연결합니다.

r33의 빌드 입력은 기존 잠금 파일이 검증한 패치 적용 전 Studio 소스와 r33에서 확인한 코어 연결 코드로 구성합니다. 보존 스크립트는 기본 런타임과 같은 디렉터리에서 인라인 빌드 입력 ZIP을 읽습니다. 별도 위치에 저장한 경우 `--studio-input-archive`로 지정합니다.

### r32: 99·100번 저장 쪽 프레임과 공통 계획

[99번 패치](rhwp-0.8.7-stored-physical-page-frame.patch)는 기존 98개를 유지하고 다음 공통 규칙을 추가합니다.

- 누락 글줄을 합성하기 전에 원본의 물리 프레임 근거를 확정합니다. 표의 바깥 상자가 후속 저장 글줄에서 정확히 닫히고 앞 쪽의 잔여를 넘으면, 표 앞 제목·안내 줄부터 시작하는 원본의 0 좌표를 연속 좌표로 덮어쓰지 않습니다.
- 문단 기준 자리차지 그림의 본체·바깥 여백·아래 캡션 전체와 후속 본문의 재시작 높이가 같으면, 그림만 다음 쪽을 소유할 수 있습니다. 캡션의 자동 번호·필드는 텍스트 구성 요소로 허용합니다. 앞쪽 호스트는 글줄 높이만 소비하고, 다음 쪽의 그림과 본문은 같은 예약 프레임을 사용합니다.
- 현재 재조판 이력과 셀 내부의 변경 이력을 확인합니다. 단순한 로컬 좌표 재시작, 겹침·용지 기준 개체, 편집으로 무효가 된 저장 프레임은 이 규칙의 근거로 쓰지 않습니다.
- 본문 문단의 가운데 정렬은 첫 줄에서도 보이지 않는 말미 공백을 제외합니다. 밑줄이 있는 공백과 셀 내부 soft-wrap의 기존 줄 폭 처리는 보존합니다.

발생 계층과 수정 범위는 **rhwp 기반 공통 코어**입니다. 공통 편집기·Desktop이 같은 WASM을 사용하며, UI에 문서별 보정이나 별도 좌표를 추가하지 않습니다. 99·100번을 고정 런타임 r32에 포함합니다. 100번의 `StoredPageFramePlan`은 높이 보완과 쪽 분할에 같은 예약 소유권을 전달하고, 개체만 있는 쪽도 실제 내용으로 판정합니다. [조건 통합 범위](CONDITION-AUDIT.md) [검증 기록](../verification/STORED-PAGE-FRAMES.md)

### r32: 98번 도형·셀 경로·연결선 속성

[98번 패치](rhwp-0.8.7-drawing-tools-and-connector-style.patch)는 r31의 97개 패치 뒤에 적용합니다. 본문과 셀 경로가 동일한 도형 생성 모델을 사용하고, 셀 삽입은 실제 소유 문단의 제어부호·문자 오프셋을 갱신합니다. 별도 임시 문서의 복사·붙여넣기를 사용하지 않습니다. 곡선·자유선과 양방향 연결선의 생성 모델을 기존 파싱·저장·그리기 경로에 연결합니다.

연결선의 레거시 링크 종류는 명시적인 화살표 속성이 없을 때만 기본값을 제공합니다. 조회·속성 변경·그리기가 이 기준을 공유하며, 시작·끝 화살표를 모두 없애는 편집은 링크 종류도 함께 갱신합니다. 도형 위치·크기 변경은 부착된 본문 연결점의 좌표를 다시 계산합니다. 선 투명도와 호·부채꼴 종류 변경은 이번 패치의 지원 범위가 아닙니다.

`patch-shape-tools.mjs`와 `patch-auto-page-arrangement.mjs`는 **Studio 공통 편집기 변경**입니다. 생성 동작을 기존 스냅샷 실행 취소에 연결하고, 자동 쪽 배치의 기본값과 사용자 선택 보존을 연결합니다. 공통·Desktop 번들에 함께 적용하며 [검증 범위](../verification/DRAWING-AND-PAGE-ARRANGEMENT.md)를 따릅니다. 새 고정 런타임 r32에 보존하며 이전 r31 자산을 덮어쓰지 않습니다.

### r31: 97번 공통 행 배치에 따른 높이 조절

[97번 패치](rhwp-0.8.7-table-resize-allocated-grid.patch)는 상대 높이 조절을 저장 최소값이 아닌 쪽 분할 전 논리 행 배치에서 시작합니다. 명시적으로 높이를 조절한 표의 행 배분을 저장 치수로 보존하고, 다른 표의 원문은 바꾸지 않습니다. 일반·중첩 경로가 같은 코드를 사용하며 기존 내용 최소 높이와 그림 이동의 여백 보존을 유지합니다. 조절용 높이 조회는 표별 공유 캐시를 사용합니다.

[편집기 연결](../../scripts/patch-table-resize-grid.mjs)은 `resizeHeight`를 드래그·단축키의 한계와 높이 맞추기에 사용하며, 기존 코어에서는 `height`로 돌아갑니다. Pwh 0.6.62 / Desktop 0.1.43의 고정 코어 r31에 포함합니다. [검증·배포 상태](../verification/TABLE-RESIZE-GRID.md)

Pwh 0.6.61의 [자동 채우기](../../scripts/patch-auto-fill.mjs)와 [대화상자 키보드](../../scripts/patch-dialog-focus.mjs)는 **Studio 공통 편집기 빌드 패치**입니다. 상하좌우 셀 내용 계산과 모달 초점·Tab 이동을 연결하며, 아래 r30 코어 보완과 함께 배포합니다. 공통·Desktop 산출물과 입력 해시를 함께 갱신합니다. [지원·시험 범위](../AUTO-FILL.md)

### r30: 91~96번 셀 그림 높이·빈 앵커·자원 재사용

r30은 기존 90개 뒤에 아래 여섯 패치를 적용합니다. 공통 편집기와 Desktop은 같은 코어를 사용하며 문서·쪽·표 번호에 따른 예외를 추가하지 않습니다.

- [91번](rhwp-0.8.7-cell-picture-size-floor.patch): 전체 경로의 그림 소유 셀을 찾아 기존 셀·표 높이를 최소값으로 보존하고 공통 컨트롤의 원시 높이도 함께 갱신합니다. 명시적 셀 크기 축소는 유지합니다.
- [92번](rhwp-0.8.7-table-border-frame-ownership.patch): 일부 머리선에서 레거시 외곽선을 추론하려면 이미 존재하는 선의 종류·굵기·색이 표 기본선과 같아야 합니다. 의도한 `NONE` 변을 복원하지 않습니다.
- [93번](rhwp-0.8.7-folded-empty-host-float-frame.patch): 저장된 짧은 빈 표 앵커와 다음 원본 글줄의 관계를 입증한 경우, 문단 간격과 개체 프레임을 한 번만 소유합니다. 쪽 분할과 그리기가 같은 배치를 사용합니다.
- [94번](rhwp-0.8.7-bounded-container-asset-reuse.patch): 불변 컨테이너의 같은 자원 바이트를 64MiB·64항목 안에서 공유합니다. 문서 소유자·키·읽기 상한을 유지하고 변경 가능한 외부 resolver는 기본적으로 제외합니다.
- [95번](rhwp-0.8.7-stored-nested-anchor-height-ownership.patch): 일반·병합 셀에서 본문 뒤 빈 중첩 표 앵커도 개체와 글줄의 합집합으로 측정합니다. 그리기의 기존 높이 규칙과 맞춥니다.
- [96번](rhwp-0.8.7-compressed-binary-export-reuse.patch): HWPX 내장 자원의 전체 SHA-256·길이·파일명으로 정규화된 압축 결과를 재사용합니다. 압축된 바이트만 최대 32MiB·64항목 보관하며, 1KiB 미만·32MiB 초과 자원은 기존 쓰기를 유지합니다. 원본 컨테이너를 그대로 복사하지 않고 기존 쓰기 방식으로 생성한 항목만 병합합니다.

공통 연결의 [복구 내보내기 조정](../../scripts/patch-background-recovery.mjs)과 [글꼴 파일 전송 공유](../../src/font-transfer.mjs)는 코어 패치와 분리합니다. [적용 범위·시험·측정 한계](../verification/CELL-PICTURE-RESOURCE-REUSE.md)

[그림 이동 빌드 패치](../../scripts/patch-picture-drag.mjs)는 Studio 마우스 입력의 최신 좌표와 mouseup을 연결하고, 이동 전 문서 체크포인트를 기존 실행 취소 기록으로 이관합니다. 공통 상태 조회와 Desktop의 반복 탭 상태 보고를 분리해 드래그 도중 불필요한 HWPX 내보내기를 없앱니다. 원천 조판 코어 패치는 추가하지 않으며, 공통·Desktop 번들과 입력 해시를 함께 생성합니다. [구현 계층과 검증](../verification/PICTURE-MOTION.md)

[탭별 그래픽 메뉴 패치](../../scripts/patch-context-ribbon.mjs)는 rhwp Studio 유래 메뉴 입력·도구 상자·명령 상태 조회를 Pwh 공통 편집기에서 보완합니다. 공통과 Desktop 번들에 함께 적용하며 메뉴 자체는 WASM 조판 규칙을 변경하지 않습니다. [소스·검증·지원 제한](../RHWP-DIFFERENCES.md#contextual-ribbon)

[문서 비교 연결](../../scripts/patch-document-compare.mjs)은 Studio의 비교 엔진과 미리보기를 사용합니다. 비교 결과 세션과 렌더러를 편집기에서 분리하여 같은 탭에서 파일과 실행 취소 기록을 유지합니다.

같은 빌드에서 [모양 복사 범위](../../scripts/patch-format-copy-options.mjs), [표시된 감추기 부호 삭제](../../scripts/patch-control-marker-delete.mjs), [상단 붙이기 연결](../../scripts/patch-native-paste-command.mjs)을 별도로 적용합니다. 원본 앵커가 맞지 않으면 빌드를 중단하고, 스크립트와 새 UI 소스는 공통·Desktop 입력 해시에 포함합니다. 인라인 그림 뒤 단어 선택은 공통 편집기의 끝점 변환만 보완하며 공통 코어의 기존 개체 API를 사용합니다. 제품 정보창에는 뷰포트 높이 제한과 본문 스크롤을 적용하며, 보존 입력에 이미 패치된 창에도 중복 없이 반영합니다.

Studio의 선택적 upstream 반영은 코어 90개 패치와 분리합니다. [클립보드·교차 구역 선택 패치](studio/clipboard-safety.patch)와 [Pwh 적용 스크립트](../../scripts/patch-clipboard-safety.mjs)는 rhwp 0.9.0의 관련 수정 세 건을 가져오고, 취소 즉시 진행 상태 해제·포커스 이탈 기록·rich 복사 실패 시 원문 보존을 추가합니다. [검토표와 검증 범위](../UPSTREAM-0.9-REVIEW.md)

한글 호환 단축키의 편집 상태 분기는 [Pwh 공통 Studio 빌드 패치](../../scripts/patch-hancom-key-contexts.mjs)에 있습니다. 고정 크기 표 조절과 행 삭제는 r22 코어 API를 사용합니다. [편집기 변경과 적용 범위](../RHWP-DIFFERENCES.md#한글-호환-단축키의-편집-상태-구분)

Pwh 0.6.59에서는 같은 스크립트가 Studio의 중복 겹글쇠 대기 맵을 제거하고 [공통 입력 모듈](../../src/table-create-shortcut.mjs)에 연결합니다. [메뉴 패치](../../scripts/patch-context-ribbon.mjs)는 열린 목록의 키를 캡처 단계에서 처리해 문서 선택·삭제에 새지 않도록 합니다. 기존 명령과 클릭 경로, WASM 코어 r29 및 기록 복원 정책은 유지하며 공통·Desktop 빌드 모두에 적용합니다. [사전·사후 시험과 제한](../verification/MENU-SHORTCUTS.md)

<a id="inline-object-cursor-and-grouped-textbox"></a>
### 89~90번 묶음 글상자와 본문 인라인 개체

r29의 [89번 패치](rhwp-0.8.7-unique-grouped-textbox-editing.patch)는 묶음 안에 글상자가 하나인 경우 조회·수정·커서 적중이 같은 원본을 사용하게 합니다. 여러 이야기가 있는 묶음은 추정하지 않습니다. [90번 패치](rhwp-0.8.7-body-inline-object-range.patch)는 인라인 개체 슬롯 조회와 논리 범위 삭제를 추가하며 기존 메타데이터 갱신·조각 복원을 사용합니다. 기존 88개 패치를 앞에 유지합니다.

[공통 Studio 연결](../../scripts/patch-inline-object-cursors.mjs)은 본문 커서의 개체 앞뒤 정보, 줄 선택, 복사·삭제·드래그와 표 좌우 바깥의 적중 판정을 함께 처리합니다. 이 빌드 스크립트는 고정 입력의 앵커가 달라지면 실패하며 공통·Desktop 번들 모두에 적용합니다. 문서·쪽·표 번호 조건이나 조판부호 클릭 기능은 추가하지 않습니다. [검증과 남은 제한](../verification/CORE-R29.md)

<a id="nested-paragraph-and-delete-metadata"></a>
### 87~88번 개체 삭제 메타데이터와 중첩 문단 서식

공통 코어 r28의 [87번](rhwp-0.8.7-delete-control-metadata.patch)은 그림·도형·수식·표 삭제의 스트림 좌표 갱신을 문단 모델에 모읍니다. Pwh의 HWPX 글줄 축·측정 키와 누름틀 소유 범위를 함께 갱신합니다. [88번](rhwp-0.8.7-nested-paragraph-format.patch)은 중첩 문단의 조회·변경·ID 복원 API를 연결하며 기존 부분 서식 병합과 dirty·배치 갱신을 유지합니다. 기존 86개 패치는 그대로 앞에 적용합니다.

[공통 Studio 연결](../../scripts/patch-nested-paragraph-format.mjs)은 실제 경로를 선택·명령·실행 취소에 전달합니다. 셀 선택 정렬 명령과 Pwh 표 클립보드의 Ctrl+Shift+C 충돌도 함께 정리합니다. AI의 글자 서식 검사는 [공통 빌드 연결](../../scripts/build-inline.mjs)에서 기존 코어의 읽기 전용 셀 주소 조회를 사용합니다. 문서·쪽 번호를 계산 조건으로 쓰지 않습니다. [사전·사후 시험과 기존 조판 유지](../verification/CORE-R28.md)

<a id="cell-command-paths"></a>
### 86번 셀 표 명령의 전체 경로

공통 코어 r27의 [패치](rhwp-0.8.7-cell-command-paths.patch)는 본문 표 생성 모델을 셀 생성과 공유하고, `createTableEx`에 `parentParaIdx`·`cellPath`를 추가합니다. `editTableStructureByPath`, `getCellOwnPropertiesByPath`, `setCellZonePropertiesByPath`는 안쪽 표의 구조·원래 테두리·영역 스타일을 직접 처리합니다. 기존 85개 패치를 보존하며 JavaScript 연결부와 WASM을 함께 배포합니다.

경로와 구조를 검사한 대상 표만 교체하고, 그 셀의 문단과 상위 표를 갱신합니다. 대화상자 조회와 실행 취소 스냅샷은 [공통 Studio 명령 패치](../../scripts/patch-table-command-access.mjs)가 같은 경로에 연결합니다. 글줄·쪽 분할·그리기 계산은 바꾸지 않습니다.

[코어 시험](../../tests/table-command-paths.test.mjs)은 여러 깊이·여러 문단·문자열 중간 삽입·치수·클립보드 유지, 병합·분할·행/열 변경, 잘못된 입력의 무변경, 원래 선과 영역 스타일, 저장·재열기를 확인합니다. [명령 서비스 시험](../../tests/table-command-services.test.mjs)은 대화상자와 스냅샷의 동일한 타깃 및 커서의 상위 경로 보존을 확인합니다. [브라우저 회귀 시험](../../tests/table-command-paths-browser.test.mjs)은 실제 키·버튼과 실행 취소를 검사합니다. [지원 목록과 검증 범위](../TABLE-COMMANDS.md)

<a id="symbol-metrics-and-stored-frame-budget"></a>
### 84~85번 기호 폭·표 분할 내용 예산

배포 기준은 공통 코어 r26입니다. [84번 패치](rhwp-0.8.7-legacy-symbol-metric-projection.patch)는 기호 폰트 원본 코드의 합성기 폭과 커서 전진량을 일치시킵니다. 표시 기호의 기존 치환과 다른 전용 문자 처리는 유지합니다.

[85번 패치](rhwp-0.8.7-stored-frame-content-budget.patch)는 저장된 첫 프레임을 채택하기 전에 실제 내용 하단을 검사하고, 원본 재시작이 입증된 HWPX의 남은 행 최소 높이를 다음 조각으로 전달합니다. 끝난 단일 줄 표제가 있는 행의 후행 간격도 원본 표 프레임이 그 간격을 제외함을 증명할 때만 제외합니다. 기존 병합·평행 셀·편집 후 재조판 조건을 유지합니다.

[기호 폭 검사](../../tests/legacy-symbol-run-advance.test.mjs), [표 연속 배치 보존](../../tests/stored-frame-visible-content-fit.test.mjs), [원본 프레임 증명 함수 검사](../../tests/stored-label-frame-source.test.mjs)를 추가했습니다. 실제 HWPX/PDF 비교 결과는 [익명 검증 보고서](../verification/CORE-R26.md)에 있으며, 사용자 문서는 배포하지 않습니다. 기존 83개 패치 뒤에 순서대로 적용합니다.

<a id="format-property-preservation"></a>
### 82번 부분 서식 병합과 83번 도형 줄 뒤 간격

[82번 코어 패치](rhwp-0.8.7-partial-format-border-preservation.patch)는 BorderFill 부분 변경에서 생략된 속성을 현재 소유자의 값으로 보존합니다. 본문·셀·머리말·꼬리말·각주·미주 문단에 같은 병합을 적용하며 새 정의에 없는 선을 기본 실선으로 만들지 않습니다. 공통 Studio의 [속성 입력 패치](../../scripts/patch-format-properties.mjs)는 무편집 확인, 지원하지 않는 저장 무늬 코드와 문단 간격 단위를 다룹니다.

[83번 코어 패치](rhwp-0.8.7-inline-shape-owned-tail-spacing.patch)는 같은 높이의 개체 프레임에서도 다음 원본 줄의 위치가 줄 뒤 간격을 증명하면 그 간격을 유지합니다. 기존 쪽 분할·점유 예산을 넓히지 않습니다. [발생 계층·영향·시험](../RHWP-DIFFERENCES.md#format-property-preservation)

<a id="nested-table-properties"></a>
### 80~81번 패치의 중첩 표 속성과 원본 경로

배포 기준은 공통 코어 r25입니다. [80번 패치](rhwp-0.8.7-nested-table-properties.patch)는 평면·중첩 표의 속성 조회·설정 로직을 공유하고 전체 셀 경로로 대상 표만 변경합니다. 바깥 여백의 HWPX 필드를 함께 갱신합니다. [81번 패치](rhwp-0.8.7-table-control-path-ownership.patch)는 표시 표에 원본 경로를 전달하고 빈 중첩 표의 좌표도 자신의 TableNode에서 찾습니다.

기존 79개 패치 뒤에 순서대로 적용합니다. 고정 upstream과 도구 버전은 유지하며, 세 개의 경로 기반 속성 API가 추가되어 JavaScript 연결부와 WASM을 함께 배포합니다. 정확한 패치·소스·산출물 해시는 BUILD-RECORD.json 및 runtime-lock.json으로 검증합니다.

[합성 시험](../../tests/nested-table-properties.test.mjs)에서 깊이별 표·셀 속성, 빈 표, 잘못된 경로, 상위 표와 이웃 셀 불변, 저장·재열기와 원래 스냅샷을 확인합니다. 익명 TEST 문서 4개 총 167쪽의 글자 좌표·인쇄 SVG와 저장·재열기 결과는 직전 r24와 같습니다. 실제 포인터와 키보드 시험은 공통 편집기의 테두리 선택·속성 편집·실행 취소·다시 실행·셀 크기 조절을 확인합니다. [원인 계층과 범위](../RHWP-DIFFERENCES.md#nested-table-properties)

<a id="continued-flow-picture-anchor"></a>
### 79번 패치의 연속 셀 자리차지 그림

[공통 코어 패치](rhwp-0.8.7-continued-flow-picture-anchor.patch)는 현재 연속 조각이 소유한 문단 기준 TopAndBottom 흐름 그림을 그 조각의 문단 시작점에 배치합니다. 셀 세로 정렬을 다시 적용해 앞의 제목·문단 높이를 지우지 않습니다. 개체 첫 단위의 소유권을 기존 분할 원장에서 확인하며 용지 상대 그림이나 제한을 끈 그림의 배치를 바꾸지 않습니다.

[합성 회귀 시험](../../tests/continued-flow-picture.test.mjs)은 그림 앞 제목 1~3개, 같은 문서의 저장·재열기, 편집 후 스냅샷 복원과 명시적 용지 상대 배치를 검사합니다. 익명 실제 TEST 문서에서는 17쪽 유지와 해당 쪽의 제목·그림 분리를 인쇄 PDF로 확인합니다. [전후 수치와 범위](../RHWP-DIFFERENCES.md#continued-flow-picture-anchor)

<a id="source-owned-render-measurement-reuse"></a>
### 78번 패치의 커서·그리기 측정 재사용

[패치 소스](rhwp-0.8.7-source-owned-render-measurement-reuse.patch)는 문서가 소유하는 표·문단만 등록해 원본 글줄 계산을 커서 조회와 화면 그리기에 전달합니다. 그리기용 임시 복제본은 이 목록의 소유 주소를 가지지 않으므로 별도로 계산합니다. 그리기의 중첩 행 높이는 같은 용지·단 프레임 안에서 재사용하고 다음 프레임에서 초기화합니다.

원본이 dirty가 되면 그리기 재사용을 중지합니다. 지연 셀 입력도 표와 셀 문단의 측정값을 무효화하므로, 쪽 분할 전 그리기가 이전 글줄을 읽지 않도록 합니다. 원본의 소유 목록은 전체 무효화 이후 다음 조판에서 등록합니다. [성능·조판 검증](../RHWP-DIFFERENCES.md#source-owned-render-measurement-reuse)

후보 WASM 경로를 지정해 자동 실행되는 [커서·그리기 회귀 시험](../../tests/cursor-layout-cache.test.mjs)을 실행할 수 있습니다. 기본 비교는 같은 원본의 표시 설정을 같은 값으로 다시 적용해 캐시를 비운 뒤 계산합니다. 직전 코어의 바인딩과 WASM을 PWH_RENDER_CACHE_BASE_JS·PWH_RENDER_CACHE_BASE_WASM으로 지정하면 별도 코어의 계산과도 대조합니다. 지연 입력의 긴 줄에서 재사용을 무효화하는 회귀를 포함합니다. 현재 배포 런타임 r23에 포함됩니다.

<a id="incremental-table-edit-measurements"></a>
### 77번 패치의 표 편집 증분 계산

[패치 소스](rhwp-0.8.7-incremental-table-edit-measurements.patch)는 최외곽·중첩 셀의 크기 조절과 중첩 셀의 문자 삽입·삭제에 같은 측정 소유권을 적용합니다. 변경 경로의 모든 상위 표와 실제로 줄을 다시 나누는 셀 문단을 갱신합니다. 같은 원본의 중첩 표 측정, 용지·본문 영역과 안 여백 조건이 같은 행 높이, 폭과 글꼴 문맥이 같은 평문 셀 글줄을 재사용합니다. 캐시는 문서 코어가 소유하고 전체 재조판·구조 변경·실행 취소 경계에서 초기화합니다. 각 캐시의 항목 수에 상한을 둡니다.

뒤쪽 쪽의 계획과 원본 의존성을 비교한 뒤 동일한 쪽의 계획·렌더 트리를 유지합니다. 편집된 호스트를 참조하는 본문·어울림·연속 표·각주·머리말·꼬리말은 갱신합니다. 분할 경계 확인 순회는 계속 수행합니다. 기존 셀 치수·그림·여백·쪽 분할의 산식은 같은 입력으로 계산합니다. [측정과 검증 범위](../RHWP-DIFFERENCES.md#incremental-table-edit-measurements)

후보 코어의 두 경로를 지정해 합성 시험을 실행합니다.

~~~powershell
$env:PWH_CORE_JS = '<candidate>/rhwp.js'
$env:PWH_CORE_WASM = '<candidate>/rhwp_bg.wasm'
node --test tests/incremental-table-layout.test.mjs tests/inline-picture-frame.test.mjs tests/nested-capacity-rewind.test.mjs
~~~

[증분 회귀 시험](../../tests/incremental-table-layout.test.mjs)은 각 편집의 모든 쪽 글자 좌표·인쇄 SVG를 일괄 편집으로 강제한 전체 재계산과 대조합니다. 바깥 셀 폭 변경, 셀 문단 재할당, 일괄 편집 후 로컬 편집, 독립된 뒤쪽 쪽, 저장·재열기와 스냅샷 복원 뒤의 재입력을 포함합니다. 현재 배포 런타임은 r23입니다.

<a id="inline-picture-frame-trailing-spacing"></a>
### 76번 패치의 쪽 끝 인라인 그림

[패치 소스](rhwp-0.8.7-inline-picture-frame-trailing-spacing.patch)는 한 셀이 쪽을 넘겨 이어지는 HWPX 표의 원본 줄을 검사합니다. 그림 하나가 글자처럼 놓여 저장 글줄 높이와 일치하고, 뒤 문단이 새 쪽 좌표에서 시작하며, 그림 끝과 셀 안 여백이 선언 프레임 안에 들어갈 때 다음 줄로 가는 간격을 현재 쪽의 그림 단위에서 제외합니다. 분할의 실제 가용 높이 검사와 그리기는 같은 셀 단위를 읽습니다. 현재 용지에 공간이 부족해 그림을 옮겨야 할 때도 그림 뒤의 확인된 쪽 경계를 유지합니다. [출력 검증 범위](../RHWP-DIFFERENCES.md#inline-picture-frame-trailing-spacing)

후보의 `PWH_CORE_JS`와 `PWH_CORE_WASM` 경로를 지정하고 `node --test tests/inline-picture-frame.test.mjs`로 그림과 뒤 표의 쪽 배치, 저장·재열기를 검사할 수 있습니다.

<a id="nested-text-capacity-continuation"></a>
### 75번 패치의 중첩 표 연속 조각

[패치 소스](rhwp-0.8.7-use-capacity-after-nested-text-frame-displacement.patch)는 실제 가용 높이로 나뉜 HWPX 중첩 표의 연속 조각에서, 다음에 만나는 평문 저장 좌표가 현재 쪽을 비우도록 강제하는 문제를 보완합니다. 같은 자식 표에서 앞서 소비한 내용 범위, 분할 속성, 명시적 쪽·단 나눔, 독립된 저장 개체 프레임과 현재 조각의 실제 높이를 확인합니다. 기존 평문 규칙과 같이 남은 공간이 해당 조각에 주어진 예산의 절반보다 커야 하며, 이어지는 줄도 그 예산 안에 들어가야 합니다. 한 단만 선언한 메타데이터는 쪽·단 나눔으로 읽지 않습니다. 원문 줄 좌표와 문서 여백은 수정하지 않습니다. [합성 조판 회귀 시험](../../tests/nested-capacity-rewind.test.mjs)

<a id="reuse-font-metric-decisions-per-run"></a>
### 74번 패치의 글꼴 폭 표 재사용

[패치 소스](rhwp-0.8.7-reuse-font-metric-decisions-per-run.patch)는 글줄 폭, 줄바꿈용 폭, 글자 경계 위치를 계산할 때 같은 서식의 글꼴 폭 표 조회를 재사용합니다. 글꼴 선택, 장평, 자간과 반올림 규칙은 기존 계산과 같습니다. [성능과 출력 검증](../RHWP-DIFFERENCES.md#reuse-font-metric-decisions-per-run)

<a id="rebuild-cell-flow-after-width-change"></a>
### 73번 패치의 셀 폭 변경 뒤 문단 위치

[패치 소스](rhwp-0.8.7-rebuild-cell-flow-after-width-change.patch)는 최외곽 표와 중첩 표의 폭 변경에서 실제 폭이 달라진 셀만 재조판하고, 기존 표 나누기 경로와 같은 문단 높이 누적 규칙으로 줄의 세로 위치를 다시 계산합니다. 합성 시험과 여러 단계로 중첩된 시험 사본에서 문단 겹침, 실행 취소와 HWPX 저장·재열기를 확인했습니다.

<a id="prepare-font-measurement-per-run"></a>
### 72번 패치의 글꼴 판별 재사용

[패치 소스](rhwp-0.8.7-prepare-font-measurement-per-run.patch)는 글줄의 문자 폭을 계산할 때 기본 글꼴과 영문 구두점 슬롯의 글꼴 이름을 미리 판별합니다. KoPub 이름의 Unicode 소문자 변환 결과와 기존 폭 계산을 그대로 사용합니다. 재사용 범위는 해당 글줄로 한정합니다. [성능과 출력 검증](../RHWP-DIFFERENCES.md#prepare-font-measurement-per-run)

<a id="viewport-table-cell-selection"></a>
### 71번 패치의 셀 선택 좌표 조회

[패치 소스](rhwp-0.8.7-viewport-table-cell-selection.patch)는 행·열·병합 구조를 모델에서 조회하고, 선택을 그릴 때 요청한 물리 쪽의 셀 경계만 조회합니다. 키보드 조절의 대상은 표 전체의 구조에서 결정하므로 화면 밖 행이나 병합 셀도 포함합니다. 기존 좌표 조회와 치수 변경 후 조판 경로를 유지합니다. 정식 r22에 71~75번 패치가 포함됩니다.

<a id="hwpx-owned-table-insets-and-reset-suffix"></a>
### 70번 패치의 표 바깥 여백과 쪽을 이은 문단

[패치 소스](rhwp-0.8.7-hwpx-owned-table-insets-and-reset-suffix.patch)는 원본 글줄에 의해 원점이 확인된 셀 끝 부동 표와, 쪽을 넘기는 문단의 인라인 표를 다룹니다. 셀 끝 부동 표의 점유 상자에는 이미 두 바깥 여백이 있으므로 그리기에서 위 여백으로 테두리만 옮깁니다. 인라인 표는 제어 문자 위치와 저장 줄 높이로 각각의 줄 소유자를 확인합니다. 쪽을 넘기기 직전 표에는 위 여백을 한 번 적용하고, 새 쪽에서 마지막 표 뒤에 이어지는 글줄은 그 쪽에 수용되는 범위에서 한 번 내보냅니다. 합성 HWPX에서 이전 코어의 본문 누락과 새 코어의 원래 쪽 복원을 확인했습니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#test-b-final-65)

<a id="hwpx-nested-column-left-anchor"></a>
### 65번 패치의 중첩 표 왼쪽 앵커

[패치 소스](rhwp-0.8.7-hwpx-nested-column-left-anchor.patch)는 원본 HWPX의 셀 안쪽에 있는 단 기준 왼쪽 정렬 위아래 배치 표를 대상으로 합니다. 행 단위 나눔을 선언한 여러 열 표의 오프셋이 0이고, 표와 좌우 바깥 여백이 상위 셀 내용 폭 안에 들어가면 셀 내용 상자의 왼쪽에 표의 왼쪽 바깥 여백을 더해 배치합니다. [TEST 문서 B 실제 인쇄 비교](../LAYOUT-FIDELITY.md#test-b-nested-column-left)

<a id="print-font-snapshot"></a>
### 66번 패치의 인쇄용 글꼴 조판 사본

[패치 소스](rhwp-0.8.7-print-font-snapshot.patch)는 HWPX 글꼴표에서 언어별 원본 이름과 대체 이름이 일치하는 비내장 TTF 선언을 읽습니다. Desktop은 인쇄 창이 실제로 로드한 글꼴만 선택해 별도 조판 사본에 넘깁니다. 사본은 출력용 좌표를 계산하는 동안 편집기의 조판과 기록에서 분리됩니다. 원래 설정으로 돌아가면 인쇄 창도 처음에 준비한 쪽을 다시 사용합니다.

<a id="hwpx-terminal-object-only-float-origin"></a>
### 67번 패치의 쪽 끝 표 원점

[패치 소스](rhwp-0.8.7-hwpx-terminal-object-only-float-origin.patch)는 앞 인라인 표의 원본 줄 높이·줄간격과 문단 간격의 합이 다음 부동 표의 저장 앵커와 일치하는지 확인합니다. 다음 문단이 명시적으로 새 쪽에서 시작하고 표 전체가 현재 쪽에 들어가면 그 저장 원점과 위 바깥 여백을 배치에 사용합니다. [TEST 문서 B 실제 인쇄 비교](../LAYOUT-FIDELITY.md#test-b-terminal-object-float)

<a id="hwpx-adjacent-source-table-anchors"></a>
### 68번 패치의 인접 원본 글줄과 표 원점

[패치 소스](rhwp-0.8.7-hwpx-adjacent-source-table-anchors.patch)는 기존 저장 인라인 표 줄의 뒤 원점 확인에 앞 글줄의 전진량 확인을 추가합니다. 두 방향에서 저장 좌표가 이어지고 선행 표를 침범하지 않으면 쪽 안의 표 원점을 복원합니다. 쪽 끝 부동 표는 앞의 일반 글줄이 저장 원점을 증명하고 아래쪽 캡션까지 쪽에 들어갈 때 같은 경로에서 처리합니다. [TEST 문서 B 실제 인쇄 비교](../LAYOUT-FIDELITY.md#test-b-adjacent-source-anchors)

<a id="hwpx-terminal-cut-merged-frame"></a>
### 69번 패치의 마지막 내용 컷과 병합 표 높이

[패치 소스](rhwp-0.8.7-hwpx-terminal-cut-merged-frame.patch)는 마지막 행의 내용이 모두 소비된 원본 HWPX의 표에서, 전체 높이를 가로지르는 병합 셀과 마지막 행의 선언 높이가 표 상자를 입증하는지 확인합니다. 다음 문단의 명시적 쪽 나누기와 현재 쪽 예산도 확인합니다. 조판 예약과 테두리는 확정된 마지막 행의 물리 높이를 함께 쓰고, 내용 컷은 보존합니다. [TEST 문서 B 실제 인쇄 비교](../LAYOUT-FIDELITY.md#test-b-terminal-cut-merged-frame)

<a id="hwpx-parallel-row-page-edge"></a>
### 28번 패치의 HWPX 표 분할

[패치 소스](rhwp-0.8.7-hwpx-parallel-row-page-edge.patch)는 고정 rhwp 원천 코어의 표 분할을 보완합니다. Pwh와 Pwh Desktop이 공유하는 WASM 빌드에 적용합니다.

반복 머리행 아래에서 나뉘는 마지막 행의 첫 조각을 대상으로 합니다. 선언 높이 안에 글줄과 셀의 위아래 여백이 들어가고, 그 뒤 줄간격을 더했을 때만 선언 경계를 넘는지 검사합니다. 같은 행의 셀들이 각각 저장한 첫 되감김도 비슷한 높이에서 다음 쪽 원점으로 돌아와야 합니다. 합성 줄, 편집한 줄, 병합으로 이어진 행, 셀의 개체가 끼어든 경계는 기존 경로를 사용합니다.

기존 컷 선택과 조각 높이 계산이 같은 규칙을 사용합니다. 현재 쪽의 본문 한계와 셀 안쪽 여백을 적용한 상태에서 줄 수용 여부를 결정합니다. 원문 속성에 저장된 줄간격 값도 보존합니다.

[합성 HWPX 시험](../../tests/hwpx-parallel-row-page-edge.test.mjs)은 글줄이 한 번만 나타나고 표 아래선 안에 들어가는지, 반복 머리행이 유지되는지 검사합니다. 다른 셀의 되감김이 없거나 본문에 글줄이 실제로 들어가지 않는 경우에는 기존 분할을 확인합니다. 배포 r18에서 재현한 기존 동작과 후보의 결과를 구분합니다.

<a id="hwpx-parallel-row-continuations"></a>
### 29번 패치의 반복 머리행 표 연속 분할

[패치 소스](rhwp-0.8.7-hwpx-parallel-row-continuations.patch)는 28번의 경계 판정을 이어지는 표 조각에도 적용합니다. 현재 셀의 실제 조각 시작 줄부터 다음 저장 원점까지의 범위를 찾고, 같은 행의 다른 셀이 같은 순서의 물리 경계를 저장했는지 대조합니다. 다음 원점이 같은 문단 안에 기록된 경우에도 이 기준을 사용합니다. 실제 쪽에 들어가는 높이는 기존 수용 계산에서 검사합니다.

합성 문서로 첫 조각과 후속 조각, 서로 다른 저장 원점, 실제 높이 부족을 비교합니다. 먼저 내용이 끝나는 형제 셀은 다음 저장 경계를 제공할 수 없어 이 적용 범위에 들지 않습니다.

<a id="hwpx-row-frame-finished-cells"></a>
### 개발 중인 30번 패치의 표 조각 수용 높이

[패치 소스](rhwp-0.8.7-hwpx-row-frame-finished-cells.patch)는 Pwh와 Pwh Desktop이 공유하는 WASM의 29번 조건을 보완합니다. 반복 머리행 아래 같은 행의 첫 저장 경계를 증명한 셀이 다음 쪽에 이어지지 않을 때, 남은 저장 줄이 해당 셀의 마지막 프레임 안에서 끝나는지 검증합니다. 다음 쪽으로 이어지는 셀은 자신이 저장한 시작·끝 위치를 그대로 검증합니다.

현재 쪽에 들어갈 글줄과 셀 안쪽 여백을 먼저 계산합니다. 본문 가용 공간 안에서 허용된 같은 조각 높이를 테두리에도 사용합니다. 이어짐이 끝나는 표는 마지막 내용이 차지하는 높이로 닫힙니다. 문서명이나 쪽 번호, 고정 용지·셀 크기로 분기하는 조건은 없습니다.

합성 문서에서 짧은 셀의 좌우 위치를 바꿔 같은 결과를 검증합니다. 잘못된 저장 원점, 가용 높이 부족, 본문 하단 넘침, 마지막 조각의 과도한 높이를 함께 검사합니다. 현재 배포판은 r20입니다.

<a id="nested-inline-projected-opening-owner"></a>
### 개발 중인 31번 패치의 중첩 표 경계

[패치 소스](rhwp-0.8.7-nested-inline-projected-opening-owner.patch)는 Pwh 공통 WASM에서 안쪽 표를 개별 행으로 분해한 뒤에도 첫 행이 원본의 다음 쪽 시작 위치를 이어받도록 합니다. 확인하는 근거는 원본 개체 높이와 바깥 여백을 담은 글줄, 다음 문단의 저장 위치, 그리고 앞쪽에서 나뉜 부모 행의 선언 범위입니다. 안쪽 표의 원본 행 높이 합계도 선언된 높이와 맞아야 합니다.

원문의 쪽 경계와 현재 측정한 높이를 구분합니다. 현재 조각의 가용 높이는 기존 분할 예산을 따릅니다. 원본 경계를 확인한 경우에만 같은 저장 높이를 앞 조각의 수용과 테두리 계산에 공유합니다. 편집한 줄이나 개체 상자 불일치, 조각 중간 커서는 기존 경로를 사용합니다.

합성 문서에서 글줄과 안쪽 표가 각 쪽에 한 번만 표시되는지, 원본 조각의 아래선 높이, 저장·재열기, 저장 상자 불일치 반례를 확인합니다. 현재 배포판은 r20입니다.

검증은 11쪽까지 통과했습니다. 12쪽은 일반 F1 **54.54% → 65.01%**, 13쪽은 **54.25% → 53.40%**이며, 전체 쪽 수는 한컴 46쪽과 Pwh 48쪽입니다. 별도 문서 3개의 71쪽은 r21과 인쇄 SVG·텍스트 위치가 같았고 저장·재열기 결과도 유지됐습니다. 코어 시험 478건 통과, 환경별 제외 64건, 실패 0건입니다.

<a id="hwpx-displaced-nested-table-line"></a>
### 개발 중인 32번 패치의 중첩 표와 글줄 배치

[패치 소스](rhwp-0.8.7-hwpx-displaced-nested-table-line.patch)는 저장된 HWPX에서 셀 첫 글줄의 세로 위치가 그 문단이 소유한 자리 차지 표의 본체 높이와 위·아래 바깥 여백의 합과 일치하는 경우를 처리합니다. 현재 측정값도 같은 상자를 확인하면, 표 뒤에서 시작하는 글줄에 표 높이를 다시 더하지 않습니다. 한 단 설정이 함께 저장된 문단도 같은 배치 근거를 사용합니다.

표와 글줄은 각자 원본 순서를 유지하고, 셀의 세로 정렬과 다음 행은 그 점유 범위를 사용합니다. 편집으로 원본 글줄을 다시 계산했거나 표 상자가 일치하지 않으면 일반 흐름을 사용합니다. 합성 문서에서 표 아래 안내문과 다음 행의 한 번 표시, 선언 높이, 저장·재열기 및 저장 좌표 불일치 반례를 검사합니다.

<a id="hwpx-parallel-picture-band"></a>
### 개발 중인 33번 패치의 표 안 사진 분할

[패치 소스](rhwp-0.8.7-hwpx-parallel-picture-band.patch)는 HWPX 셀의 두 원본 문단에 걸친 사진을 처리합니다. 첫 글줄 뒤에 오는 사진 두 장의 저장 세로 좌표가 같은 배치 범위를 가리키고 가로 범위가 분리되어 있으면, 두 사진을 한 높이로 계산합니다. 두 사진을 모두 수용할 수 있는 쪽에서 함께 배치하며, 사진마다 원래 제어문자와 그리기 소유권을 유지합니다. 다음 쪽에서 그릴 때도 분할에 예약한 묶음의 시작 위치를 사용해 뒤 행과 겹치지 않도록 합니다. 가로 범위가 겹치거나 저장 좌표가 바뀐 경우는 기존 계산을 사용합니다.

합성 문서에서 두 사진이 모두 다음 쪽에 한 번씩 배치되는지, 테두리 안에 그려지는지, 후속 내용과 저장·재열기가 유지되는지 확인합니다. 사진의 가로 범위가 겹치는 반례도 비교합니다.

32·33번을 함께 적용한 실제 Pwh Desktop 인쇄 PDF에서 12쪽 안내문이 안쪽 표 아래로 복원됐습니다. 한컴 대비 안내문 상단 오차는 1.07pt이며, 다음 바깥 행의 시작점 오차는 125.86pt에서 1.22pt로 줄었습니다. 사진 두 장은 모두 13쪽에 한 번씩 배치됩니다. 두 사진 상단의 차이는 0.15pt이며, 가장 낮은 사진과 다음 행 사이에는 1.41pt가 남습니다.

별도 3개 문서 71쪽의 코어 인쇄 SVG와 텍스트 위치는 r22와 동일하고, 저장·재열기 결과도 유지됐습니다. 전체 코어 시험은 480건 통과, 환경별 제외 64건, 실패 0건입니다. 현재 배포판은 r20이며 이번 결과는 로컬 후보입니다.

<a id="hwpx-paired-rowbreak-opening-frame"></a>
### 개발 중인 64번 패치의 마지막 행 분할 높이

[패치 소스](rhwp-0.8.7-hwpx-paired-rowbreak-opening-frame.patch)는 저장된 HWPX 위아래 배치 표의 마지막 행이 실제로 두 조각으로 나뉘고, 빈 표 앵커와 다음 쪽의 빈 문단이 원본 높이를 입증할 때 적용합니다. 전체 행 높이와 첫 조각 선언 높이의 차이가 마지막 행보다 작고, 그 잔여 높이와 바깥 여백의 합이 다음 원본 문단 위치와 정확히 맞아야 합니다. 실제 조각 예산과 내용 컷을 확인한 뒤 첫 조각 높이를 조판 예약과 그리기에 공유합니다. 합성 HWPX에서 앞뒤 셀 높이와 원문 배정을 확인하고, 원본 원점이 1HU 어긋나는 대조군도 시험했습니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#paired-rowbreak-opening-frame)

<a id="hwpx-paragraph-right-float-frame"></a>
### 개발 중인 63번 패치의 문단 기준 오른쪽 정렬 표

[패치 소스](rhwp-0.8.7-hwpx-paragraph-right-float-frame.patch)는 글자처럼 취급하지 않는 본문 흐름의 위아래 배치 표를 대상으로 합니다. 가로 기준이 문단이고 정렬이 오른쪽이면 문단 오른쪽에서 부호 있는 오프셋, 오른쪽 바깥 여백, 표 본체 폭을 뺍니다. 이 가로 계산을 표의 배치 범위와 그리기, 분할 조각에서 공유합니다.

세로는 기존 저장 앵커 경로를 확장합니다. 폭 0인 빈 호스트의 원점이 앞 저장 글줄 높이와 줄 간격으로 확인되고, 다음 문단은 새 쪽 원점에서 시작하며, 실측 높이와 선언 높이가 맞을 때 위 바깥 여백을 한 번 적용합니다. 편집·재조판으로 원본 좌표의 근거가 없거나 표가 물리 쪽에 들어가지 않으면 이 원점으로 고정하지 않습니다. 양수·음수 가로 오프셋, 본문보다 넓거나 좁은 표와 새 쪽 재시작을 합성 HWPX로 시험했습니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#paragraph-right-float-frame)

<a id="print-faux-bold-text"></a>
### 개발 중인 62번 패치의 합성 굵기 인쇄

[패치 소스](rhwp-0.8.7-print-faux-bold-text.patch)는 일반 글줄의 합성 굵기에 기존 글꼴·위치와 0.02em 획을 사용합니다. 인쇄 SVG는 검색할 수 있는 채움과 장식 획을 분리하고, 획을 SVG 필터를 거쳐 그래픽으로 내보냅니다. 이 처리로 Chromium PDF에서 채움과 획이 같은 글자로 두 번 추출되던 문제를 줄입니다. 합성 굵기 글줄의 화면 SVG와 쪽 나누기에는 같은 기존 코드를 사용합니다. 별도 회전 글자·글자 겹침 경로는 검증 범위 밖입니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#print-faux-bold-text)

<a id="hwpx-terminal-inline-frame"></a>
### 개발 중인 61번 패치의 쪽 끝 인라인 표

[패치 소스](rhwp-0.8.7-hwpx-terminal-inline-frame.patch)는 앞 표의 저장 줄 높이와 줄 간격으로 현재 표의 시작점을 확인합니다. 현재 표의 전용 줄은 본체와 바깥 여백을 포함해야 하며 다음 문단에는 명시적 쪽 나누기와 새 원점이 있어야 합니다. 용지에 들어가는 온전한 표의 시작과 행 높이에 같은 물리 단위를 사용합니다. 행 높이 환산은 실측 높이와 원본 선언이 맞는 경우에 적용합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#terminal-inline-frame)

<a id="hwpx-source-inline-tab-and-float-anchors"></a>
### 개발 중인 60번 패치의 원본 앵커와 목차 정렬

[패치 소스](rhwp-0.8.7-hwpx-source-inline-tab-and-float-anchors.patch)는 아래 원본 속성이 일치할 때 저장 배치를 사용합니다.

- 인라인 표의 본체와 바깥 여백이 전용 줄의 높이와 같고, 다음 문단 위치에 그 줄의 간격과 문단 뒤 간격이 확인됩니다.
- 가운데 정렬 글상자의 단일 오른쪽 탭과 리더가 있는 숫자 꼬리는 저장 탭 폭을 따릅니다. 번호 뒤의 공백은 보이는 번호 끝 바깥에서 처리합니다.
- 쪽 나누기 앞의 떠 있는 표는 앞 글줄과 같은 원점에서 이어지고, 앵커 오프셋과 실제 쪽에 남은 공간이 입증된 경우 저장 위치를 적용합니다.
- 글상자에 포함된 새 쪽 번호와 감추기 설정은 그 개체의 쪽에서 적용합니다. 감추기와 재시작 앞에서 이미 활성화된 쪽 번호를 유지합니다.

[실제 인쇄 비교](../LAYOUT-FIDELITY.md#source-inline-tab-and-float-anchors)

<a id="hwpx-resumed-peer-frame-margins"></a>
### 개발 중인 59번 패치의 재개 표 여백

[패치 소스](rhwp-0.8.7-hwpx-resumed-peer-frame-margins.patch)는 원본 앵커와 분할 커서를 통해 이어지는 상위 표와 새로 시작하는 안쪽 표의 위 여백을 구분합니다. 앞 조각에서 끝난 셀을 다시 열지 않고, 새로 시작하는 표의 여백을 그 행에 이미 예약된 높이 안에서 한 번 적용합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#resumed-peer-frame-margins)

<a id="hwpx-terminal-peer-leaf-frame"></a>
### 개발 중인 58번 패치의 중첩 표 마지막 조각

[패치 소스](rhwp-0.8.7-hwpx-terminal-peer-leaf-frame.patch)는 원본 글줄의 연속성과 중첩 표의 저장 높이를 대조합니다. 완전한 앞 행, 행 사이 간격, 현재 조각에 속한 셀의 글줄과 여백이 저장 높이에 정확히 맞을 때만 같은 행의 떠 있는 표를 다음 조각으로 넘깁니다. 앞 조각에서 이미 끝난 셀과 다음 조각에서 시작할 셀에 각각의 원문 커서를 유지하고, 같은 분할 경계를 높이와 테두리 계산에도 사용합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#terminal-peer-leaf-frame)

<a id="hwpx-parallel-declared-source-frames"></a>
### 개발 중인 57번 패치의 여러 셀과 같은 쪽 경계

[패치 소스](rhwp-0.8.7-hwpx-parallel-declared-source-frames.patch)는 같은 행의 셀이 각자의 원본 줄과 앞뒤 순서로 재시작을 입증하면 해당 줄을 한 쪽 경계에 묶습니다. 다음 조각에 올 인라인 표와 각 셀의 원래 정렬을 유지합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#parallel-declared-source-frames)

<a id="hwpx-complete-float-row-frame"></a>
### 개발 중인 56번 패치의 떠 있는 표와 온전한 행

[패치 소스](rhwp-0.8.7-hwpx-complete-float-row-frame.patch)는 행 전체의 저장 줄과 떠 있는 표 앵커가 이어지고 실제 내용이 남은 본문 높이에 들어갈 때, 마지막 글줄까지 해당 쪽에 배치합니다. 원본 행의 높이보다 현재 쪽이 작으면 실제 조각에 맞춰 테두리를 닫습니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#complete-float-row-frame)

<a id="hwpx-source-frame-height-reconciliation"></a>
### 개발 중인 55번 패치의 연속 표 높이 기준

[패치 소스](rhwp-0.8.7-hwpx-source-frame-height-reconciliation.patch)는 원본 위치와 완전한 앞 행으로 확인한 연속 표의 저장 행 높이에 용지의 물리 좌표 변환을 적용합니다. 완전한 중간 행도 같은 변환을 사용하고, 한컴 인쇄에서 관측한 600dpi 경계에서 사용량을 결정합니다. 다음 조각의 인라인 표 전용 줄에 더 큰 공간이 필요하면 그 줄과 나머지 글줄을 수용할 최소 높이를 적용합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#source-frame-height-reconciliation)

<a id="hwpx-inline-declared-row-frame"></a>
### 개발 중인 54번 패치의 인라인 표 전용 줄

[패치 소스](rhwp-0.8.7-hwpx-inline-declared-row-frame.patch)는 저장된 전용 줄 높이가 인라인 표 본체와 바깥 여백의 합으로 확인되면, 그 줄의 전진량을 앞 조각에 한 번 사용합니다. 각 조각의 남은 행 높이와 글줄 높이는 분할·세로 정렬에 함께 사용합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#inline-declared-row-frame)

<a id="hwpx-declared-row-fragment-balance"></a>
### 개발 중인 53번 패치의 여러 쪽에 걸친 저장 행 높이

[패치 소스](rhwp-0.8.7-hwpx-declared-row-fragment-balance.patch)는 원래 행 높이가 같은 셀들과 저장 줄 원점이 확인된 이어지는 셀을 검사합니다. 앞 조각에 사용한 행 높이를 한 번 빼고 남은 높이를 다음 조각으로 넘깁니다. 떠 있는 안쪽 표는 앞 앵커와 다음 줄 좌표가 본체·오프셋·여백과 일치할 때 원래 위치에 놓습니다. 가운데·아래 정렬은 같은 조각에 배정된 내용의 높이를 사용합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#declared-row-fragment-balance)

<a id="hwpx-terminal-nested-row-prefix"></a>
### 개발 중인 51번 패치의 마지막 안쪽 표 분할

[패치 소스](rhwp-0.8.7-hwpx-terminal-nested-row-prefix.patch)는 앞 표가 끝나는 문단과 마지막 안쪽 표의 앵커가 원본 좌표에서 이어지고, 안쪽 표의 선언 높이가 완전한 앞 행들의 합과 일치할 때 그 경계를 사용합니다. 중간 행의 실측 높이, 조각의 바깥 여백, 다음 쪽의 내용 시작점을 분할과 그리기에서 공유합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#nested-table-prefix-and-anchored-opening)

<a id="hwpx-anchored-opening-zone-visibility"></a>
### 개발 중인 52번 패치의 후속 표 앵커와 셀 영역 가시 범위

[패치 소스](rhwp-0.8.7-hwpx-anchored-opening-zone-visibility.patch)는 제목을 포함한 원본 문단과 표의 선언 높이로 앞 행 범위를 확인합니다. 그 범위를 그릴 때 세로 오프셋을 제목 문단 기준으로 한 번 적용합니다. 부분 조각과 겹치는 행이 없는 셀 영역은 배경, 대각선, 테두리의 그리기 대상에서 제외합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#nested-table-prefix-and-anchored-opening)

<a id="hwpx-closed-object-row-frame"></a>
### 개발 중인 50번 패치의 떠 있는 표와 저장 행 높이

[패치 소스](rhwp-0.8.7-hwpx-closed-object-row-frame.patch)는 떠 있는 표의 전체 높이와 바깥 여백이 앵커 글줄의 이동을 정확히 설명하는지 확인합니다. 다음 쪽의 글줄과 인라인 표도 원본 좌표와 높이가 맞으면, 현재 조각은 저장 행 높이에서 닫힙니다. 선언 높이가 글줄이나 여백을 자르거나 원본 프레임과 맞지 않으면 일반 분할 계산을 사용합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#closed-object-row-frame)

<a id="hwpx-plain-leaf-source-frame"></a>
### 개발 중인 48번 패치의 안쪽 표 글줄 경계

[패치 소스](rhwp-0.8.7-hwpx-plain-leaf-source-frame.patch)는 안쪽 표에서 문단의 저장 원점이 다시 나타날 때, 그 전의 글줄과 셀 여백으로 선언된 앞쪽 표 높이를 입증합니다. 줄을 세는 단계와 그리는 단계가 같은 경계에서 내용 커서를 나누고 앞뒤 조각의 바깥 여백을 계상합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#source-table-boundaries-33-34)

<a id="hwpx-parallel-plain-source-restart"></a>
### 개발 중인 49번 패치의 이웃 셀 쪽 경계

[패치 소스](rhwp-0.8.7-hwpx-parallel-plain-source-restart.patch)는 같은 행에서 두 개 이상의 셀이 각자의 저장 원점과 앞 글줄의 전진량으로 쪽 경계를 입증하면 각 셀을 자신의 경계까지 배치합니다. 문단 내부와 문단 사이에 저장된 경계를 함께 확인하며, 물리 상자와 세로 정렬은 같은 쪽 경계를 사용합니다. [실제 인쇄 비교](../LAYOUT-FIDELITY.md#source-table-boundaries-33-34)

<a id="hwpx-anchored-float-restart-frame"></a>
### 개발 중인 47번 패치의 떠 있는 표 시작점과 앞 조각 테두리

[패치 소스](rhwp-0.8.7-hwpx-anchored-float-restart-frame.patch)는 저장된 새 세로 원점과 표의 오프셋, 표 뒤의 빈 문단과 다음 글줄이 같은 쪽 경계를 입증할 때 기존 중첩 행 분할 규칙을 적용합니다. 측정에서 결정한 테두리 높이를 앞 조각의 세로 정렬과 함께 사용합니다. [인쇄 검증과 범위](../LAYOUT-FIDELITY.md#anchored-float-restart-frame)

<a id="hwpx-closed-inline-row-ownership"></a>
### 개발 중인 46번 패치의 인라인 표 행 높이와 쪽 분할

[패치 소스](rhwp-0.8.7-hwpx-closed-inline-row-ownership.patch)는 여러 문단과 글줄에 걸친 저장 전진량을 확인하고, 셀 여백을 합한 행 높이가 전체 표를 정확히 닫을 때 측정과 그리기에 같은 값을 씁니다. 1단 설정을 함께 담은 표 전용 줄도 원본 셀이 전체 표를 수용하면 분할 단위 하나로 예약합니다. [인쇄 검증과 범위](../LAYOUT-FIDELITY.md#closed-inline-row-ownership)

<a id="hwpx-nested-restart-frame-ownership"></a>
### 개발 중인 45번 패치의 중첩 표 연속 조각

[패치 소스](rhwp-0.8.7-hwpx-nested-restart-frame-ownership.patch)는 원본 글줄의 좌표 재시작과 다음 문단의 위치를 검증해 글줄의 쪽 소유권을 결정합니다. 이미 예약한 안쪽 행의 높이는 다음 조각의 계산에 한 번만 반영하고, 바깥 표의 테두리 높이는 안쪽 행에 전달하지 않습니다. 원본 인라인 표가 앞쪽에 포함된 조각은 다음 쪽으로 이어지는 줄간격을 현재 조각의 글 정렬에서 제외합니다. [인쇄 검증과 범위](../LAYOUT-FIDELITY.md#nested-restart-frame-ownership)

<a id="hwpx-nested-original-text-restart"></a>
### 개발 중인 44번 패치의 중첩 행과 원본 줄 경계

[패치 소스](rhwp-0.8.7-hwpx-nested-original-text-restart.patch)는 같은 문단의 저장 줄이 새 원점에서 이어지는 경우 앞뒤 표 조각을 따로 측정합니다. 원본이 같은 경계를 입증하는 이웃 셀은 각 줄의 높이에 맞춰 함께 배치합니다. 남은 행 높이와 내용의 수용량을 각각 계산해 앞뒤 조각과 커서 좌표 조회에 전달합니다. [인쇄 검증과 범위](../LAYOUT-FIDELITY.md#nested-original-text-restart)

<a id="hwpx-original-inline-object-line"></a>
### 개발 중인 43번 패치의 인라인 표 전용 줄

[패치 소스](rhwp-0.8.7-hwpx-original-inline-object-line.patch)는 앞 글줄과 인라인 표가 각자의 저장 줄에 있고, 마지막 줄 높이가 표 본체와 바깥 여백의 합으로 확인될 때 해당 줄에 공간을 한 번만 예약합니다. 부분 표에 그릴 때도 같은 저장 줄의 원점을 사용합니다. [인쇄 검증과 범위](../LAYOUT-FIDELITY.md#original-inline-object-line)

<a id="hwpx-nested-terminal-frame-continuation"></a>
### 개발 중인 42번 패치의 중첩 표 쪽 경계

[패치 소스](rhwp-0.8.7-hwpx-nested-terminal-frame-continuation.patch)는 원래 글줄과 인라인 표의 높이·여백이 맞는 행에서 내용 컷과 빈 행의 물리 높이를 따로 보존합니다. 다음 쪽은 빈 높이를 먼저 예약합니다. 원본의 별도 문단이 세로 원점에서 다시 시작하며 인라인 표의 전체 높이를 입증하면, 같은 행의 다른 셀은 확인된 앞 조각에 남깁니다.

배치와 커서 좌표 조회는 같은 조각 기록을 받습니다. 원본 높이, 쪽 본문 한계와 셀 여백을 사용하며 분할 계산은 문서의 저장 높이를 수정하지 않습니다. [실제 인쇄 검증과 범위](../LAYOUT-FIDELITY.md#nested-terminal-inline-row-band-trial)

<a id="hwpx-nested-table-frame-ledger"></a>
### 개발 중인 41번 패치의 중첩 표 연속 조각

[패치 소스](rhwp-0.8.7-hwpx-nested-table-frame-ledger.patch)는 완전한 행들의 원래 글줄·셀 안 여백과 마지막 행의 첫 줄이 표에 저장된 높이를 모두 설명할 때 행 안쪽 분할을 전달합니다. 다음 문단의 저장 원점은 이어지는 조각 높이와 바깥 여백의 합을 확인하는 데 사용합니다. 행 사이 분할에서도 저장 글줄과 안 여백으로 같은 경계를 입증할 수 있습니다.

검증된 표의 원래 왼쪽 기준점은 상위 셀의 안쪽 영역에서 계산합니다. 높이 계산은 이어지는 조각의 줄과 여백을 사용하며, 아래쪽 안 여백이 이미 예약됐으면 해당 공간을 흐름에 유지하고 테두리 위치에서 구분합니다. 사용 중인 줄 위치가 다시 계산된 경우에는 저장 원점에 의한 분할을 적용하지 않습니다.

[실제 인쇄 검증과 범위](../LAYOUT-FIDELITY.md#nested-table-frame-ledger)

<a id="hwpx-nested-rowspan-opening"></a>
### 개발 중인 40번 패치의 세로 병합 중첩 표 분할

[패치 소스](rhwp-0.8.7-hwpx-nested-rowspan-opening.patch)는 직접 작성된 HWPX의 자리 차지 중첩 표에서, 이미 시작된 세로 병합을 통과하는 행의 일반 셀을 원본 줄에서 나눕니다. 두 셀 이상에서 이어지는 글줄의 저장 세로 위치와 가로 범위가 맞고, 먼저 끝나는 셀도 첫 조각 안에 들어가야 합니다. 원본 표 높이에서 앞의 완전한 행들을 뺀 높이를 첫 조각에 사용합니다. 글자나 셀 속성이 다시 계산된 문서에는 저장 경계를 그대로 적용하지 않습니다.

상위 표의 앞 행들과 안쪽 표 첫 조각의 높이·여백이 원본 선언을 닫을 때, 쪽 나눔과 실제 배치에서 같은 공간을 사용합니다. 직전 쪽의 표 끝과 뒤 빈 줄이 맞고 현재 쪽의 평문 위치가 원점에서 다시 시작하면 상위 표의 바깥 위 여백을 복원합니다.

시험 사본에서 표 높이 조절 여부, 줄 폭, 실제 단 수, 선언 높이를 각각 바꿔 저장 분할이 적용되지 않는 경우도 확인했습니다. [실제 인쇄 검증과 범위](../LAYOUT-FIDELITY.md#nested-rowspan-opening-trial)

<a id="hwpx-stored-nested-row-geometry"></a>
### 개발 중인 39번 패치의 중첩 표 행 경계와 앵커

[패치 소스](rhwp-0.8.7-hwpx-stored-nested-row-geometry.patch)는 저장된 인라인 표에서 글줄 높이와 유효 안 여백으로 구한 행들이 원본 표 높이를 닫고 병합 셀의 내용도 수용할 때 그 행 경계를 측정과 배치에 함께 사용합니다. 원본에 저장된 수식 결과는 대응하는 필드 범위와 한 줄이 확인되면 줄 상자로 계산합니다.

문단에 붙은 자리 차지 표는 표 아래에 저장된 빈 줄로 원래 배치를 확인할 수 있습니다. 표의 시작점이 원본 글줄 아래에 있고, 문단 기준 오프셋과 표 높이 및 바깥 여백의 합이 다음 줄을 닫아야 합니다. 한 단으로 유지되는 단 설정은 새 단 나눔을 만들지 않습니다. 여러 문단이 있는 행이 하나일 때 저장된 전체 높이의 남는 부분을 그 행에 배정하며, 앞 조각에서 이미 확인한 분할 경계로 재개할 때 위쪽 표 여백을 다시 적용합니다.

별도 합성 시험에서 병합 셀이 들어갈 공간이 부족한 경우, 다른 종류의 필드, 실제 다단 설정, 대상 행이 둘 이상인 경우와 줄 위에 겹치는 경우를 대조했습니다. [실제 인쇄 검증과 범위](../LAYOUT-FIDELITY.md#stored-nested-row-geometry)

<a id="hwpx-confirmed-row-frame-reservation"></a>
### 개발 중인 38번 패치의 분할 행 높이 예약

[패치 소스](rhwp-0.8.7-hwpx-confirmed-row-frame-reservation.patch)는 HWPX 중첩 표에서 이미 결정된 원문 분할 경계와 현재 행의 물리 높이를 분리합니다. 편집되지 않은 셀들이 같은 저장 높이를 갖고, 이어지는 인라인 표 또는 연속 평문이 독립된 저장 프레임을 입증하면 그 행의 높이를 별도로 요청합니다. 부모 표가 저장 쪽 경계 표시를 가진 경우에도 자식에서 입증한 같은 경계를 사용합니다. 실제 남은 높이로 제한한 예약을 테두리와 셀 세로 정렬에서 공유합니다.

합성 사례에서 저장 줄 위치 차이, 비어 있는 줄, 다단 설정, 불확실한 분할, 가용 공간 부족은 제외했습니다. 기준 문서의 실제 Desktop 인쇄에서는 15쪽과 16쪽이 순서대로 통과했습니다. 별도 문서에서 적용된 두 쪽은 원문 범위를 유지했고 바깥 표 아래선이 한컴에 가까워졌습니다. [전후 점수와 검증 범위](../LAYOUT-FIDELITY.md#confirmed-row-frame-reservation)

<a id="hwpx-resumed-nested-left-anchor"></a>
### 개발 중인 37번 패치의 중첩 표 가로 정렬

[패치 소스](rhwp-0.8.7-hwpx-resumed-nested-left-anchor.patch)는 36번 규칙으로 전체 소유가 확인된 다음 쪽 어울림 표의 문단 기준 왼쪽 앵커를 사용합니다. 가로 오프셋이 0이고 표와 좌우 바깥 여백이 셀 내용 폭에 들어가야 합니다. 가로 기준을 계산해도 기존 세로 원점과 내용 분할은 유지합니다.

<a id="hwpx-resumed-nested-successor"></a>
### 개발 중인 36번 패치의 중첩 표 뒤 문단 배치

[패치 소스](rhwp-0.8.7-hwpx-resumed-nested-successor.patch)는 원본의 한 줄 제목이 앞 조각에서 끝나고 같은 문단의 어울림 표 전체가 새 조각에 놓인 경우를 처리합니다. 새 조각에 표와 마지막 글줄이 온전히 포함되는지 확인합니다. 마지막 글줄의 저장 시작점이 표 본체와 위·아래 바깥 여백의 합과 같고, 표 실측값도 같은 저장 단위로 닫힐 때 그 좌표를 뒤 글줄의 원점과 조각 높이에 함께 사용합니다.

원본과 조각의 단위가 일치하는 합성 사례를 확인하고, 표 일부가 앞쪽에 이미 배치된 경우, 1 HWPUNIT의 차이, 원본 줄 편집, 어울림 외 배치, 겹침, 별도 문단 간격을 제외하는 시험을 추가했습니다.

최종 r28의 실제 Desktop 인쇄 PDF에서는 r27 대비 14쪽만 바뀌었습니다. 참고 문단의 세로 위치 오차는 **3.41pt → 0.41pt**이며 바로 아래 행의 경계 오차는 **3.09pt → 0.09pt**입니다. 14쪽의 일반·진한 F1은 **90.26% → 96.28%**, **74.54% → 89.34%**입니다. 본문 484개와 글머리표, 테두리의 본문 경계 준수를 확인했습니다. 진한 잉크 기준 90%에는 0.66%p 모자라 승인 범위는 1~13쪽입니다. 위쪽 중첩 표의 가로 경계는 한컴보다 2.59~2.81pt 오른쪽에 있고, 바깥 표 아래선은 1.36pt 아래에 있습니다. r28은 로컬 후보입니다.

별도 HWP·HWPX 4개 문서 110쪽의 원문, 인쇄 SVG, 글줄 좌표와 저장·재열기 결과가 r27과 같았습니다. 전체 코어 회귀는 **482건 통과·64건 환경별 제외·실패 0건**입니다.

<a id="hwpx-stored-plain-tail-frame"></a>
### 개발 중인 35번 패치의 중첩 표와 여러 줄 셀

[패치 소스](rhwp-0.8.7-stored-plain-tail-frame.patch)는 중첩 표의 저장 분할 판정에 원본 여러 줄 셀의 높이를 반영합니다. 셀의 저장 높이가 위·아래 안 여백과 같으면 원본 글줄의 마지막 끝점에 그 여백을 더해 행이 실제로 차지하는 높이를 확인합니다. 글자처럼 배치한 안쪽 표 옆에 여러 줄이 있는 경우에는 같은 방식으로 그 셀 높이를 검증합니다.

첫 조각의 실측 합이 원본 표의 선언 높이와 일치하고, 이어지는 행의 높이와 바깥 여백의 합이 뒤 문단의 저장 시작 좌표와 일치해야 합니다. 높이가 달라진 행의 원본 셀들이 실측값과 맞고 분할 경계를 가로지르는 병합 셀이 없어야 합니다. 검증된 경계는 기존 분할·배치 경로가 함께 사용합니다.

코어 소스 시험에서 여러 줄이 있는 옆 셀, 안 여백만 저장된 이어지는 행, 1 HWPUNIT의 불일치와 옆 셀이 행 높이를 초과하는 사례를 검사합니다.

<a id="hwpx-stored-picture-opening-frame"></a>
### 개발 중인 34번 패치의 표 조각 높이와 정렬

[패치 소스](rhwp-0.8.7-hwpx-stored-picture-opening-frame.patch)는 사진 묶음 앞에서 안쪽 표가 나뉘는 경우 저장된 첫 조각의 높이를 복원합니다. 먼저 사진이 이어지는 행의 끝 커서를 확인합니다. 그 이전 행의 글줄·안 여백과 마지막 행의 원본 높이가 선언된 안쪽 표 상자를 닫아야 합니다.

바깥 행에서는 내용이 모두 끝난 셀들이 같은 저장 높이를 갖고, 안쪽 표가 있는 셀의 원본 높이와 글줄·여백이 해당 조각의 내용에 맞을 때 그 높이를 보존합니다. 테두리는 행 전체의 높이를 쓰고, 세로 정렬은 현재 쪽에 배치된 내용만 사용합니다. 이어지는 표에는 확인된 경계가 소유한 바깥 여백만 적용합니다. 편집되거나 다른 원본 속성이 이 결정을 뒷받침하지 않는 조각은 일반 분할 경로를 따릅니다.

문서명·쪽 번호·고정된 용지 크기와 관계없이 같은 원본 속성에 적용합니다. 합성 시험에서 행 높이·가운데 정렬·사진의 쪽과 저장·재열기, 같은 행 셀 높이가 불일치하는 반례를 검사합니다.

### r18: 셀 편집 전 상태 복원

27번 [`scoped-cell-text-history`](rhwp-0.8.7-scoped-cell-text-history.patch)는 r17 뒤에 적용합니다. 기존 삭제 조각 API에 셀 문단의 구조 경로를 보관하는 캡처를 추가하고, 복원 시 해당 셀의 뒤쪽 줄 좌표와 저장 프레임 이력도 돌려놓습니다. 일반 문서 열기와 페이지 배치 규칙에는 변화가 없습니다. 공통 Studio가 이 캡처를 사용하는 조건과 시험은 [셀 텍스트 실행 취소](CELL-TEXT-HISTORY.md)에 정리합니다.

<a id="r17-caret-and-continuation"></a>
### r17: 글자 커서와 중첩 표의 연속 배치

**Pwh 0.6.44 · Desktop 0.1.25 / r17.** r16의 22개 패치 뒤에 커서 기하, 인라인 표 분할 인계, 반복 머리행 예약, 문단 기준 표 순서를 다루는 23~26번을 추가합니다. 정식 코어·공통 편집기·실제 PDF의 소스 검증과 배포물별 설치 검증은 구분합니다.

23번 [`glyph-caret-metrics`](rhwp-0.8.7-glyph-caret-metrics.patch)는 글자 크기·baseline으로 삽입 커서를 계산하고 원래 hit 상자는 보존합니다. 24번은 자식 표의 실제 분할 경계를 상위 소비에 전달하고, 25번은 반복 머리행의 물리 공간을 예약합니다. 26번은 고정 rhwp 원본의 source-order fallback을 원본 프레임이 증명되는 경우에 한해 보완합니다. 각 수정의 발생 계층과 정확한 지원 조건은 [커서와 표 연속 분할](CARET-AND-CONTINUATION.md)에 정리합니다.

이 26개 Rust 패치와 별도로 rhwp Studio 유래의 클릭 좌표 캐시와 깊은 셀 Home/End 기하를 공통 편집기에서 보완했습니다. [Studio 수정의 조건과 검증](CARET-AND-CONTINUATION.md#studio-pointer-hit-geometry)을 참고하세요. 전체 시험·39쪽 PDF·별도 71쪽의 검증과 남은 범위는 [r17 검증 기록](../LAYOUT-FIDELITY.md#r17-caret-and-continuation)에 모으며, 설치·실행 결과는 해당 릴리스에 첨부한 `DESKTOP-VERIFICATION.json`으로 확인합니다.

### r16: 중첩 표의 순방향 분할과 물리 프레임

**Pwh 0.6.43 · Desktop 0.1.24 / r16.** 열아홉 번째 [`rhwp-0.8.7-nested-forward-frame-ownership.patch`](rhwp-0.8.7-nested-forward-frame-ownership.patch)는 기존 r15의 열여덟 패치 뒤에 적용합니다. 기존 파일 12개와 새 보조 이력 모듈 1개, 총 13개 소스를 다룹니다. Pwh·Desktop 공통 rhwp 코어의 추가 패치이며 원본 프로젝트에 병합됐다는 뜻은 아닙니다.

- 내용의 시작·끝 커서와 실제 행 프레임을 분리합니다. 원문이 증명하는 다음 쪽 경계를 스캐너·블록 수용·상위 투영이 함께 사용하고, 물리적 여유 공간을 복구할 때 내용 커서를 앞당기지 않습니다.
- 현재 쪽 용량과 부모 셀·자식 표의 여백 소유를 확인해 같은 공간을 한 번만 배정합니다. 가운데 정렬도 해당 행의 내용과 프레임으로 계산합니다. 실측 위치 보정 상수나 원문 셀 높이 변경은 추가하지 않습니다.
- 이번 Pwh 후보에서 재조판 이력이 저장·재열기 시 사라져 오래된 프레임을 다시 승인한 회귀를 수정합니다. `META-INF/rhwp-source-layout-history.json` 생성·복원은 새 `model/source_layout_history.rs`와 HWPX 읽기·쓰기 경로가 담당하며, 본문·서식·줄 배치의 표준 XML은 바꾸지 않습니다.

보조 이력은 실제로 출력한 header·구역 XML의 SHA-256, 표 순번과 셀 행·열·병합 범위의 구조 경로, 대상 문단 지문을 함께 확인합니다. 메모리 주소나 정렬 전 셀 인덱스를 저장하지 않습니다. 미지원 버전·알 수 없는 필드·중복·깊이·개수·크기 상한을 검사하고 과거 JSON을 그대로 통과시키지 않습니다. 복원 값은 원본 프레임 증명에서만 거절 조건으로 쓰며 실제 공백 메트릭을 복구하지 않습니다. 보조 이력이 없거나 외부 재저장으로 불일치하면 이력 없이 기존 원문 판정을 사용하므로, 외부 편집기를 거친 뒤의 동일 조판을 보장하지 않습니다.

<a id="r16-interaction-and-fallback"></a>
### r16 추가 보완: 작은 용지 대체 경로와 커서·높이 변경

**다음 세 패치는 r16의 누적 20~22번입니다.** 소스·합성 시험·격리 후보 검증과 공식 산출물의 최종 검증을 구분합니다. 적용 순서와 파일별 전후 해시는 [`build-patched-core.mjs`](../../scripts/build-patched-core.mjs)에 고정합니다.

| 번호 | 패치 | 발생 계층과 수정 범위 |
| --- | --- | --- |
| 20 | [`authenticated-float-projection`](rhwp-0.8.7-authenticated-float-projection.patch) | **Pwh 17번 패치의 회귀.** 원본 `cell_units`의 투영 배제 조건을 예약·그리기와 같은 전체 원문 프레임 검증으로 맞춥니다. `table_layout.rs` 한 곳의 소비 조건을 변경합니다. |
| 21 | [`cell-caret-fragment-geometry`](rhwp-0.8.7-cell-caret-fragment-geometry.patch) | **고정 rhwp 원천 코어의 커서 계산.** 글줄 없는 이어진 셀에서 셀 높이를 커서 높이로 사용하지 않습니다. `cursor_rect.rs`에서 같은 구역·같은 셀의 실제 글줄 경계와 진짜 빈 셀의 서식 기반 기하를 구분합니다. |
| 22 | [`scoped-table-height-and-bbox-query`](rhwp-0.8.7-scoped-table-height-and-bbox-query.patch) | **고정 rhwp 원천 코어의 측정·조회 비용.** 높이 전용 명령의 한정된 측정 재사용과 표 경계 직접 조회를 보완합니다. `table_ops.rs`, `queries/rendering.rs`, `height_measurer.rs`, `commands/object_ops/table.rs`, `cursor_rect.rs`를 변경합니다. |

20번의 원인은 외형 조건으로 기존 행 분할을 먼저 막은 뒤, 실제 물리 프레임은 본문에 들어가지 않아 사용할 수 없게 된 상태였습니다. 17번부터 재현되며 19번에서 새로 생긴 문제가 아닙니다. 작은 용지의 실제 중복·누락·음수 좌표를 확인했고 독립 r13과 전체 SVG·텍스트 배치를 비교해 바로잡았습니다. 원래 소비 조건 시험 33개를 유지하면서 제외 조건 5개를 추가했습니다. 기존 작은 용지 3개는 CI에서 독립 r13 기준 코어를 반드시 전달하도록 연결했으며 기대값을 바꾸지 않았습니다. [원문 프레임 조건](NESTED-FLOAT-FRAMES.md#small-paper-fallback)

21번은 다른 구역에서 우연히 같은 인덱스를 가진 셀을 찾지 않도록 구역 소유권을 확인합니다. 중첩 래퍼가 화면 트리에서 생략된 경우에도 원문 셀 경로를 유지하고, 화면 안으로 제한된 실제 커서 좌표와 클릭 결과가 같은 경계를 사용합니다. 진짜 빈 셀의 기본 기하를 이미 글줄이 있는 셀의 대체값으로 무조건 사용하지 않습니다. [실제 코어 커서 시험](../../tests/cell-caret-fragment.test.mjs)

22번의 측정 재사용은 변경 전 조판이 정리된 비배치 상태이고, 미완료 지연 조판이 없고, 높이만 바꾸며, 변경 전후 전체 조판 프로필이 같은 경우에 한합니다. 변경된 최상위 표와 그 하위 표는 다시 측정하고 같은 문단의 바뀌지 않은 형제 표만 이전 값을 사용합니다. 구역 정규화·전체 페이지 배치는 그대로 수행합니다. 폭 변경, 혼합 변경, 앞선 미처리 수정, HWP 첫 편집으로 인한 프로필 전환, 캐시 부재는 기존 경로로 돌아갑니다. 재사용 범위를 문서에 영구 저장하지 않고 한 번의 호출 인자로 전달합니다. [8종 독립 대조 시험](../../tests/stored-cell-height-scope.test.mjs)

### r15: 검증 소스와 제품 버전 보존

r15는 r14의 같은 WASM 코어·연결부와 열여덟 패치를 유지하며, Pwh 0.6.42·Desktop 0.1.23과 실제 잉크 검증 소스를 보존합니다. 새 Rust 조판 패치는 없습니다. 자동 검증은 공통 정책의 150 dpi·2픽셀을 그대로 사용하며 글꼴 상자와 실제 잉크 손실을 구분합니다. [검증 도구의 범위](../RENDER-COMPARISON.md#svg-ink)를 참고하세요.

### r14: 저장 프레임과 중첩 개체 소유권

Pwh 0.6.41과 Desktop 0.1.22는 같은 **r14** 코어를 사용합니다. `scripts/build-patched-core.mjs`는 고정 원본에 기존 열네 패치와 다음 네 패치를 순서대로 적용합니다. 열여덟 패치와 코어·연결부·편집기를 검증한 불변 런타임의 해시는 `runtime-lock.json`과 보존 아카이브에 기록합니다.

1. [`rhwp-0.8.7-stored-parallel-frame-minimum.patch`](rhwp-0.8.7-stored-parallel-frame-minimum.patch)는 빈 저장 호스트의 표 바깥 여백과 나란한 셀의 공통 선언 최소 높이를 실제 조각 상자에 보존합니다. 승인된 `source_parallel_frame`만 그리기·커서에 전달합니다.
2. [`rhwp-0.8.7-page-number-source-activation.patch`](rhwp-0.8.7-page-number-source-activation.patch)는 쪽 번호 설정이 실제 소유 조각의 원문 순서에서 시작하도록 합니다. 기존 번호 재시작·감추기·일반 글줄 판정은 유지합니다.
3. [`rhwp-0.8.7-stored-nested-float-frames.patch`](rhwp-0.8.7-stored-nested-float-frames.patch)는 중첩 개체의 첫 물리 프레임·자기 바깥 여백과 이미 소비한 형제 표 앵커를 측정·그리기에 일치시킵니다. 가시 호스트 줄 아래 float는 실제 한 줄·다음 원본 줄이 닫는 프레임·본문 용량을 함께 확인합니다. 현재 재조판의 공간 측정값은 원본 증거로 인정하지 않습니다.
4. [`rhwp-0.8.7-stored-nested-tail-owner.patch`](rhwp-0.8.7-stored-nested-tail-owner.patch)는 다음 쪽 행의 원문을 미리 소비하지 않도록 일반 스캐너·행 전체 수용·상위 표 커서가 같은 경계를 사용하게 합니다. 원래 행의 여백·중첩 위치·그림 문단 기준점을 유지하고, 그림 공간 속성 편집 뒤에는 해당 호스트의 저장 배치 캐시를 무효화합니다. [안정된 본문·소스 조건과 반례](STORED-NESTED-TAIL.md)를 참고하세요.

발생 위치는 **rhwp 조판 코어**입니다. 일부 float 표시 순서 문제는 Pwh r13 코어 패치의 회귀이며 수정 전 upstream 전체의 결함으로 설명하지 않습니다. Pwh·Desktop이 공유하는 WASM으로, Studio 메뉴나 Desktop 호스트에서 문서별 좌표를 보정하지 않습니다. 패치·단계별 소스 해시는 빌드 스크립트에 고정하며 원본 ZIP에 열여덟 패치를 적용해 재현합니다. [프레임 소유권](STORED-FRAME-OWNERSHIP.md), [중첩 개체의 조건·반례](NESTED-FLOAT-FRAMES.md)를 참고하세요.

### r13: 혼합 문단의 표·본문 순서와 프레임 점유

`rhwp-0.8.7-mixed-block-flow-ledger.patch`는 r12 뒤에 추가하는 **rhwp 원천 코어** 패치입니다. 계산과 일반·부분 셀의 배치가 같은 명시적 자식 분할 단위 순서를 사용합니다. 단일 위아래 배치 표가 원문 글의 앞·뒤에 있는 경우에 적용하며 중간 앵커, 겹침 개체, 여러 컨트롤은 기존 경로를 유지합니다. 컨트롤 텍스트 위치는 문자 인덱스이므로 UTF-16 저장 길이와 혼용하지 않습니다.

`CELL`의 용량에 따른 분할은 저장 프레임의 강제 쪽 나눔과 별개입니다. 교차 행 병합을 기존 경로에 두고, 실제 저장 프레임을 가진 행의 선언 높이에 포함된 빈 공간을 자식 단위에 다시 배분하지 않습니다. 글줄 선택 범위가 없어도 해당 조각의 자식 행 범위가 있으면 표를 배치합니다. 원문의 글·글꼴·여백·선언 셀 높이·클리핑 정책은 바꾸지 않습니다.

Pwh 0.6.40과 Desktop 0.1.21의 최종 런타임은 r13이며 총 열네 패치를 적용합니다. r12는 중간 검증 후보이며 별도로 공개 배포하지 않았습니다. 정확한 변경 전후 해시와 ABI 검사는 `scripts/build-patched-core.mjs`와 코어 `BUILD-RECORD.json`에 보존합니다. 시험용 진단 API는 배포 코어에 포함하지 않습니다.

긴 중첩 표 PDF는 43 → 39쪽(한컴 39쪽), F1 53.1177% → 66.8308%, 진한 글자·선 42.6597% → 53.6753%로 개선됐습니다. 쪽 수가 같아도 일부 배치 차이가 남습니다. 다른 문서의 71쪽 인쇄 SVG는 유지합니다. [측정 범위와 한계](../LAYOUT-FIDELITY.md#r13-mixed-block-flow), `tests/mixed-block-source-order.test.mjs`, `tests/nested-declared-row-pagination.test.mjs`를 함께 확인하세요.

### r12: 저장된 중첩 행의 분할과 인라인 개체 줄

`rhwp-0.8.7-nested-declared-frame-cuts.patch`는 **rhwp 원천 코어**의 중첩 표 분할을 보완합니다. 기존 열두 패치에 추가하며 Pwh와 Desktop이 같은 WASM을 사용합니다.

- 빈 문단에 담긴 단일 위아래 배치 표도 혼합 문단과 같은 자식 분할 커서를 전달합니다. 선언 높이가 있는 행이라도 실제 저장 줄이 다음 프레임으로 이어지면, 일반 글과 안쪽 표를 가진 셀의 일부를 남은 공간에 넣을 수 있습니다. 수정되었거나 합성된 좌표로 저장 경계를 새로 증명하지 않으며, 행을 가로지르는 병합은 기존 경로를 유지합니다.
- 부모의 분할 후보에는 자식의 실제 시작·끝 커서를 기록합니다. 기존 일반 텍스트 소유자 동기화 판정을 빈 호스트에서도 사용해, 저장된 프레임 경계를 지나 뒤쪽 원문을 미리 소비하지 않게 합니다. 임의의 셀 좌표 재시작이나 새 컨트롤 호스트를 물리 쪽 경계로 승격하지 않습니다.
- 빈 문단의 인라인 표가 하나의 실제 저장 줄 상자 안에 온전히 들어 있으면, 그 개체 줄을 하나의 분할 단위로 유지합니다. 내부 표의 첫 행만 앞 쪽에 떼어 넣지 않습니다. 저장 줄 상자가 전체 표보다 작거나 줄 배치가 없거나 편집된 경우에는 기존 재귀 분할을 유지합니다. 캡션이 있는 개체도 기존 경로를 유지합니다.

선언 셀 높이·글꼴·여백·원문 텍스트와 클리핑 정책은 바꾸지 않습니다. 특정 문서 이름이나 쪽 번호에 따른 분기는 없습니다. `tests/nested-declared-row-pagination.test.mjs`는 남은 공간 사용, 원문 셀 주소, 크기 보존, 내보내기·재열기·편집·실행 취소와 저장된 인라인 줄의 완전·불완전 상자를 검사합니다. 사용자 원문은 공개 시험에 포함하지 않습니다.

중간 r12 후보는 총 열세 패치를 적용했습니다. 코어 WASM은 13,782,475바이트이며 SHA256은 `1349c8d702e0c966a47236531fc0129a6c09234975b0bd1d002880d28515bd61`입니다. JavaScript 연결부는 기존 ABI와 같은 `e4b17c467ec6e5955393f7b9b162150ea0f16271085dcec7955bcd87c0014d47`입니다. 새 패치의 SHA256은 `54d274f77865dc18586d6726558394a47b28bbb304d075318d61ea9ea9037d87`이고, 수정된 `table_layout.rs`의 최종 해시는 `d2c51ac55b1b560f7ab6c965ba0837332c7e72012e42fcaad88eaa0f99128dbf`입니다. 고정 입력·연쇄 적용 전후 해시는 `BUILD-RECORD.json`으로 검증합니다.

긴 중첩 표 PDF 비교는 F1 53.1177% → 61.0154%, 진한 글자·선 42.6597% → 49.3457%이며 43쪽이 41쪽으로 줄었습니다. 한컴 기준은 39쪽이라 쪽 흐름 차이가 남습니다. 다른 65·4·2쪽의 인쇄 SVG 71개는 r11과 동일했습니다. [PDF 비교 방법](../RENDER-COMPARISON.md#pdf-comparison)를 함께 확인하세요.

### 저장 쪽 원점과 빈 중첩 표 호스트

r11은 기존 열 패치 뒤에 두 **rhwp 원천 코어** 패치를 추가합니다. Pwh와 Desktop은 같은 WASM과 일치하는 JavaScript 연결부로 빌드합니다.

- rhwp-0.8.7-stored-page-leading-margin.patch: 첫 줄의 앞 간격과 다음 줄까지의 높이·줄 간격·앞뒤 간격을 함께 확인합니다. 다음 앞 간격 0과 명시적 쪽 나눔도 처리합니다. 전체 바깥 상자가 확인되는 첫 TAC 표는 같은 앞 간격을 측정·렌더에 전달하며, 메모·구역 설정 같은 폭 중립 부호를 허용합니다. 첫 호스트 개체 뒤에도 검증한 쪽 원점을 유지합니다. 합성·편집·다른 쪽·불일치 사다리와 별도 개체 원점은 구분하고, 큰 정수의 차는 넓은 정수로 계산합니다.
- rhwp-0.8.7-stored-nested-block-host.patch: 셀 원점에 저장된 단일 빈 호스트 문단의 단일 위아래 배치 표에서는 글줄과 표가 같은 점유 상자를 소유합니다. 높이 측정의 합산을 큰 쪽의 높이로 바꿔 이미 같은 상자를 쓰는 분할 원장·렌더와 맞춥니다. 가시 글·추가 문단·편집된 호스트·오프셋·겹침 표는 기존 경로를 유지합니다. 저장된 셀 크기는 바꾸지 않습니다.

공개 회귀는 tests/stored-page-margin.test.mjs, tests/stored-nested-block-host.test.mjs에 있습니다. 첫 표·도형·메모, HWP·HWPX 재열기, 부모 셀과 자식 표의 상자·쪽 경계·원문 크기 보존과 반례를 검사합니다. 65쪽 PDF의 전체 F1은 95.4732% → 97.4468%, 진한 글자·선은 93.3195% → 95.6349%입니다. 6쪽 개선·59쪽 유지·악화 0쪽이며, 43쪽의 후속 표 간격 등은 남아 있습니다. [측정 조건과 한계](../LAYOUT-FIDELITY.md)를 함께 확인하세요.

### r9·r10의 유지 범위

r10은 아래 r9 코어와 같은 WASM·JavaScript 연결부를 사용합니다. 변경은 Pwh·Desktop 번들의 경로 정규화, 빌드 입력 기록과 CI 재현 검사에 있으며 Rust 패치는 추가하지 않았습니다.

Pwh 0.6.38과 Desktop 0.1.19의 린트·엄격한 타입 검사 보완도 기존 r10 런타임을 유지합니다. 공통·Desktop 편집기 JavaScript는 이전 배포본과 바이트까지 같으며, Pwh 어댑터와 빌드 선언의 타입을 정리했습니다. [정적 검사 범위](../STATIC-CHECKS.md)를 참고하세요.

### 저장 프레임·기본 글머리표·도형 속성

r9는 기존 일곱 패치 뒤에 다음 세 패치를 적용합니다. 모두 **rhwp 원천 코어** 변경이며, Pwh와 Desktop의 같은 편집기 WASM을 사용합니다.

- `rhwp-0.8.7-closed-float-successor-frame.patch`: 빈 호스트 표의 lane 경로도 기존 `stored_empty_control_table_frame`이 확인한 다음 문단 원점을 유지합니다. 측정한 표 높이와 바깥 여백이 저장된 다음 줄 위치를 정확히 닫고, 단·편집 상태·재조판·겹침·쪽 예산이 맞을 때만 사용합니다. 저장된 셀 크기나 원문은 바꾸지 않습니다.
- `rhwp-0.8.7-implicit-bullet-marker.patch`: `BULLET`의 참조 0에 내장 원형 글머리표와 본문 글자 모양을 사용합니다. 명시 참조 1을 대신 쓰지 않으며 잘못된 비영 참조에는 글머리표를 새로 만들지 않습니다.
- `rhwp-0.8.7-shape-fill-transparency.patch`: HWPX 채움의 0~255 투명도 바이트를 읽고 같은 값으로 저장합니다. `ShapeStyle.fill_opacity`를 별도로 두어 채움 때문에 윤곽선까지 사라지지 않게 하며 Canvas·SVG·그리기 JSON과 관련 Skia 경로에 전달합니다. 둥근 사각형은 짧은 변에 비율을 적용하고 반지름을 절반으로 제한합니다.

이 변경에는 문서 이름·기관명·쪽 번호·특정 문단 번호를 이용한 분기가 없습니다. [조판 일치 검증](../LAYOUT-FIDELITY.md)과 `tests/stored-float-frame.test.mjs`, `tests/shape-fill-transparency.test.mjs`가 범위와 반례를 설명합니다.

### 각주·미주의 커서·클릭·삭제 주소

`rhwp-0.8.7-note-cursor-source-offsets.patch`는 **rhwp 원천 코어**의 본문 주석 참조를 보완합니다. 화면에 보이는 번호와 조판부호는 여러 글자 폭이지만, 원문에서는 하나의 논리 컨트롤 슬롯입니다. 기존 클릭 경로는 이 표시를 본문 글자처럼 읽거나 주석 슬롯을 빠뜨리고, 삭제 조회는 논리 주소 대신 순수 텍스트 위치를 사용했습니다. 서로 다른 주소 체계 때문에 주석 뒤를 클릭해도 앞의 본문이 지워질 수 있었습니다.

주석 번호·부호에 컨트롤 인덱스와 논리 위치를 연결하고, 문장 중간의 부호도 실제 주석 옆에서 생성합니다. 커서 조회·클릭·키보드 삭제가 같은 경계를 사용합니다. 표시 문자열을 검색해 원문 대상을 추측하지 않습니다. 주석 삭제 시에는 기존 `Paragraph::control_utf16_positions`로 개별 원본 컨트롤의 시작 위치를 구해 글자 모양과 범위 정보를 이동합니다. 문단 끝에 주석이 있을 때 위치를 0으로 간주해 이전 서식이 무너지는 경우도 포함합니다.

코어의 논리 위치와 Studio 본문 편집 API의 순수 글자 위치는 별도 계약입니다. Pwh 공통 편집기에서 기존 변환 API로 두 좌표를 연결하고 주석 바로 앞·뒤의 방향을 보존합니다. 주석 옆 글자의 실행 취소에는 기존 문단 조각 복원을 사용해 원문 컨트롤 위치와 서식을 함께 복원합니다. 이 연결은 WASM 소스 패치와 구분되는 Studio 빌드 변경이며 [편집기 검증](../EDITOR-PERFORMANCE.md)에 설명합니다.

이 보완은 본문의 각주·미주 참조에 적용하며, 표 셀 내부 주석 편집 전체를 새로 지원한다는 뜻은 아닙니다. 문장 앞·중간·끝, 조판부호 표시·숨김, 여러 주석, 인접 본문·혼합 글자 서식·저장 후 주소를 합성 문서로 검사합니다. 실제 입력의 삭제 확인·취소·실행 취소는 공통 편집기 브라우저 검사로 구분합니다. 원본 기준과 소스 변경 전후 해시는 `scripts/build-patched-core.mjs` 및 배포 코어의 `BUILD-RECORD.json`에 보존합니다.

### 문단 중간의 떠 있는 표 위치

`rhwp-0.8.7-interior-float-anchor.patch`는 한 줄의 보이는 텍스트 사이에 떠 있는 표가 들어간 경우, 앞뒤 글자와 표의 실제 문자 오프셋을 확인한 뒤 해당 줄의 저장된 위치 또는 계산된 위치를 표의 호스트로 사용합니다. 문자 오프셋이 불완전하거나 여러 줄에 걸치는 경우, 겹침 여부가 확실하지 않은 경우에는 기존 경로를 유지합니다. 특정 문서의 이름이나 좌표를 기준으로 보정하지 않습니다.

제공받은 4쪽 HWP 문서는 한글에서 출력한 PDF와 새 엔진의 출력을 겹쳐 확인했습니다. 3쪽의 두 번째 표와 앞 문단 간격이 가까워졌고 나머지 세 쪽의 비교 결과는 이전과 같았습니다. 글꼴 및 출력 방식의 차이는 남아 있으므로 이것이 모든 문서의 동일한 조판을 보장하지는 않습니다. 원본·출력물은 공개 패치에 포함하지 않습니다. 합성 문서의 중첩 표 및 줄 나눔 회귀 검사도 통과했습니다.

높이 측정 단계에서는 줄바꿈한 텍스트에 맞게 행을 늘리고, 표 전체 높이를 유지하기 위해 다른 행의 여유 공간을 회수할 수 있습니다. 이후 `LayoutEngine::trust_declared_row_heights`는 행 높이의 합이 같고 차이가 기존 허용 범위 안에 있으면 각 행의 원래 높이를 복원할 수 있습니다. 저장된 LINE_SEG 정보가 없는 생성 HWPX는 ViewText 내용 격자로 판정될 수 있습니다. 이때 지정된 높이를 복원하면 표 전체 높이는 그대로여도 실제 내용에 필요한 최소 높이가 사라질 수 있습니다.

`rhwp-0.8.7-nols-row-content-floor.patch`는 높이를 복원하기 전에 조건을 한 번 더 확인합니다. 높이가 줄어들 가로쓰기 NO_LS 셀에 대해 렌더러의 기존 기준 너비, 안쪽 여백, 줄바꿈 및 내용 높이 계산을 재사용합니다. 내용과 여백이 지정된 행 높이에 들어가지 않으면 측정된 행 높이를 유지합니다. 내용이 들어가는 ViewText 격자, 저장된 배치 정보가 있는 셀, 높이가 줄지 않는 행에는 기존 보정을 그대로 사용합니다. 세로쓰기도 변경하지 않습니다. 패치에는 특정 문서 ID, 기관명, 글꼴, 행 개수 또는 셀 번호를 넣지 않았습니다.

첫 번째 패치는 `src/renderer/layout/table_layout.rs`만 변경합니다. 보조 함수에는 유일한 호출 위치에서 기존에 해석한 스타일을 전달합니다.

두 번째 패치 `rhwp-0.8.7-inline-table-affect-line-spacing.patch`는 `affectLSpacing` 속성이 켜진 새 인라인 표 뒤의 간격을 보완합니다. 기존 대체 경로는 퍼센트 줄 간격을 항상 표를 담은 문단의 글꼴 높이로 계산했습니다. 그 밖에 내용이 없는 문단에 표 하나만 있는 경우에는 이 속성에 따라 개체 줄 상자(표 높이와 위·아래 바깥 여백)를 퍼센트 계산의 기준으로 사용합니다. 현재 검증된 기준은 저장된 개체 줄의 배치 정보로 확인한 **지정 표 프레임**(`table.common.height`와 바깥 여백)입니다. 셀 내용이 늘어난 뒤 달라진 측정 높이는 이 보조 함수에서 추정하지 않습니다. 검증된 원래 배치에서 해당 속성을 무시하면 다음 문단이 한컴 한글보다 표에 지나치게 가깝게 그려질 수 있습니다.

`src/renderer/mod.rs`의 보조 함수가 표 내용 높이와 추가 간격을 제공합니다. `src/renderer/composer/line_breaking.rs`는 다음 문단들의 세로 위치를 누적하기 전에, 새 호스트의 합성 LINE_SEG를 만들면서 이 간격을 기록합니다. 이후 높이 측정, 조판, 그리기 및 커서 위치 조회가 같은 계산 위치를 사용할 수 있습니다. 뒤쪽 대체 경로만 바꾸는 것으로는 충분하지 않습니다. 가져오기 과정에서 이미 글꼴 기준 간격의 합성 호스트 구간을 만들 수 있기 때문입니다. 해당 구간이 없거나 다시 생성될 때는 `src/renderer/layout.rs`의 기존 표 호스트 측정 대체 경로와 그리기 흐름도 같은 보조 함수를 사용합니다. DPI는 호출 측에서 전달합니다.

이 변경은 다음 조건을 모두 만족할 때 적용됩니다. **실제로 저장된** LINE_SEG가 없고, 문단 텍스트가 없으며, TAC 표가 정확히 하나이고, `affectLSpacing=1`이며, 퍼센트 줄 간격이 100%를 초과해야 합니다. 기존 합성 태그 판별로 식별되는 내부 생성 구간은 계속 적용 대상입니다. 개체 줄 프레임이 호스트 글꼴 높이보다 클 때만 적용합니다. 속성이 꺼진 경우, 실제 저장 LINE_SEG, 작은 개체, 혼합 컨트롤, 보이는 텍스트, 100% 간격 및 다른 간격 방식은 기존 경로를 유지합니다. 그림과 도형의 측정값도 변경하지 않습니다. 바깥 여백은 퍼센트 기준에 한 번만 포함합니다. 흐름 계산이 여백을 별도로 반영하므로 보조 함수의 내용 높이에서는 제외합니다. 기존 표 배치 진행량 뒤에 간격을 중복해서 더하지 않습니다.

차이에 포함된 원본 코드와 주석은 원래 저작자 표시를 유지합니다. rhwp의 저작권은 Edward Kim과 기여자에게 있으며 MIT 라이선스로 배포됩니다. 소스 ZIP의 `LICENSE`, 저장소의 `THIRD_PARTY_NOTICES.md` 및 원본 프로젝트 <https://github.com/edwardkim/rhwp>를 참고하세요.

<a id="pinned-inputs"></a>
## 고정된 빌드 입력

<a id="nested-table-source-ownership"></a>
### 중첩 표의 원문 소유 범위

`rhwp-0.8.7-nested-source-ownership.patch`는 기존 자식 `RowCut` 경로를 첫 번째 컨트롤 위치에 비인라인 `TopAndBottom` RowBreak 표 하나가 있는 혼합 문단으로 확장합니다. 호스트 텍스트는 자신의 줄, 간격 및 나눔 단위를 유지합니다. 자식 행·셀 커서는 고정 높이의 단순 조각에서 다시 구성하지 않고 부분 배치에 전달합니다.

자식 분할은 남아 있는 보이는 내용의 소유 범위가 원래 일반 텍스트 문단의 재시작 위치에서 시작할 때에만 저장된 원문 프레임 경계를 사용할 수 있습니다. 이미 끝난 라벨 셀은 다음 페이지의 이어지는 내용을 소유하지 않습니다. 중첩 컨트롤 조각, 합성되었거나 오래된 줄 배치, 지원하지 않는 병합 범위 및 소유 범위가 불분명한 경우에는 그 권한을 부여하지 않습니다. 표는 유형이 지정된 표 단위를 포함한 분할에서만 그립니다. 일반 호스트 텍스트가 같은 블록 표를 다시 그리지 않습니다.

저장된 문단에서 유형이 지정된 자식 실행 구간은 선택된 자식 `RowCut`의 실제 높이도 확보하며, 각 조각의 셀 안쪽 여백을 포함합니다. 실행 구간에 자식 분할의 명시적인 출처가 있으면 자리 표시용 시각 줄이 있는 빈 호스트도 포함합니다. 완전한 행은 부분 행 분할과 같은 실행 구간을 공유할 수 있습니다. 자리 표시용 줄 범위만으로는 실제 높이 확보를 승인하지 않습니다. 같은 확보 높이를 쪽 나눔과 부분 행 렌더링에 사용합니다. 이전에는 부모가 원문 단위에서 투영한 높이만 예약하는 동안 자식은 안쪽 여백도 그려 내부 테두리가 부모 프레임 아래로 내려갈 수 있었습니다. 분리된 혼합 호스트 텍스트 단위는 문단 간격을 유지하고, 빈 호스트는 기존 가장자리 간격의 소유 범위를 유지합니다. 유형이 지정되지 않은 저장 스칼라 투영은 기존 경로를 사용합니다. 고정된 여백이나 픽셀 보정은 추가하지 않습니다.

이 패치는 계산된 쪽 나눔과 렌더링을 바꾸면서 원문 텍스트와 원본 커서 주소를 유지합니다. 저장된 셀 크기를 바꾸거나 보기 설정으로 넘친 내용을 가리지 않으며, 특정 문서나 쪽 식별자를 포함하지 않습니다.

이 패치는 소스·합성 문서·실제 문서 회귀 검사를 거쳐 r4 런타임에 반영됐습니다. **당시 r4 편집기 WASM**의 크기는 13,758,962바이트이고 SHA256은 `22516f486ced5fbff3a957b34e0d48adf77a05f8c0e80d8b7ff834d35ef5919b`입니다. 재현 가능한 빌드 스크립트는 현재 패치를 순서대로 적용하고 각 소스의 변경 전후 해시를 검증합니다. 회귀 검사 명령과 합성 테스트 자료는 [`tests/engine-source-ownership`](../../tests/engine-source-ownership/README.md)에 있습니다.

| 입력 | 식별 정보 / SHA256 |
| --- | --- |
| 원본 소스 커밋 | `1a76570e833917d15817415a53c09ad61ab3203f` |
| 보존된 소스 ZIP | `pwh-upstream-rhwp-0.8.7-1a76570e8339.zip` |
| 소스 ZIP SHA256 | `067feefc25d36921ee41fea5df6fead00255ffa86441891fbaa202f96de202a2` |
| 원본 `table_layout.rs` SHA256 | `1dcbd3254a0f68b7de40c922f10e15cb62f2ef85e2c59fb24050bb143fa5f5f9` |
| 패치 적용 후 `table_layout.rs` SHA256 | `c3df908c978e4aef7876b555c4a4c7b85749587194b4755d43e4c5ae9c67c238` |
| 첫 번째 패치 SHA256 | `5a2427c162ee3928b7edecbaabad10936700c7db02f25a5436fb0a74a92bd221` |
| 인라인 표 간격 패치 SHA256 | `a9f6a533debe686f6e89ec06870e47ccb0357635f8303775467ceb6cfca9da7a` |
| 중첩 원문 소유 범위 패치 SHA256 | `346e2885cb5720574515167db94448f256e5d210d729ee63e2c0ac732e5b2a96` |
| 저장된 확장 표의 쪽 나눔 패치 SHA256 | `596bf711aaf4494438c76e0b77aa29741c93f2cdb9b75c5b49e3e4c3364eade3` |
| 저장 배치가 없는 떠 있는 표의 흐름 패치 SHA256 | `174b98deb82291af3238e56b08b807c177e0478898091c652664ead2737c3f11` |
| `saved/blank2010.hwp` | 13,824바이트; `43f472751fafefb8c66b0f831660ebed51e443a46bebe44c75bba918154ce4c9` |
| Rust / Cargo | `1.93.1` |
| 컴파일 대상 | `wasm32-unknown-unknown` |
| wasm-bindgen CLI | `0.2.127`; `--target web --out-name rhwp` |

두 번째 패치의 소스 해시는 다음과 같습니다.

| 파일 | 원본 SHA256 | 패치 적용 후 SHA256 |
| --- | --- | --- |
| `src/renderer/mod.rs` | `b27c1148d0496fe02dfef5ee3375511c3f2cd110925ebbfe90398a67b018f15d` | `c9191193db4a0b14a936887fac5ffd99f47d77311f60dc58b961574048c3271a` |
| `src/renderer/composer/line_breaking.rs` | `42a685bc83d81e01356a5576fcc03d0c92117d5054d018c84f77ddbad297921e` | `6ced0b75cf4b46090801dd05adabe6e715d9ff06e22468ead3dbd5e6fbc9b940` |
| `src/renderer/layout.rs` | `eb561f70fed2217db8e17efc8b33a5639de4dd5c8087797cd2cf876be4bc4ca5` | `81fef37b2cd464f007d721edcdaf938d6ba47439dc9418c8745bc7da927d7a61` |

세 번째 패치는 앞의 두 패치가 적용된 다음 적용합니다.

| 파일 | 적용 전 SHA256 | 적용 후 SHA256 |
| --- | --- | --- |
| `src/renderer/layout/table_layout.rs` | `c3df908c978e4aef7876b555c4a4c7b85749587194b4755d43e4c5ae9c67c238` | `7f294df11f7dc48611cdcfbf8a7fa813763778dd9c4573cd619c06bc4c26990a` |
| `src/renderer/layout/table_partial.rs` | `9e0a4d66d00906d4c949481088dba04d81d1f04ac1091b09188d65a9140ddeab` | `cebac7b673a9c051bf31e64bcc6d2310f669b74a97bfd6351d663a9cc5b452d6` |

네 번째 패치는 저장된 인라인 표의 일반 텍스트 행이 저장된 크기보다 커졌을 때 측정된 높이를 유지하고, 쪽 나눔에도 같은 높이를 사용합니다. 저장된 셀 크기, 텍스트 및 중첩 표의 표시 영역 규칙은 변경하지 않습니다. 합성 저장 표 테스트 자료로 내용의 쪽 경계 안 배치와 내보낸 뒤 다시 열었을 때의 내용 보존을 확인합니다.

다섯 번째 패치 `rhwp-0.8.7-unsegmented-float-flow.patch`는 저장된 줄 배치가 없는 빈 앵커 문단에서, 문단 기준 아래쪽으로 이동한 떠 있는 표의 실제 끝을 다음 본문의 시작 위치에 반영합니다. 같은 앵커의 글 앞·글 뒤 개체는 본문 흐름 높이를 차지하지 않습니다. 적용 범위는 하나의 위아래 배치 표와 앞·뒤 겹침 개체, 저장 줄 배치가 없는 다음 일반 텍스트 문단으로 한정합니다. 쪽 나눔과 실제 그리기가 같은 높이를 사용하며, 원문의 텍스트·표 속성은 바꾸지 않습니다. 저장된 줄 배치가 있거나 흐름 표가 여럿인 경우에는 기존 경로를 유지합니다.

고정된 소스 ZIP은 변경하지 않는 engine-r2 릴리스에서 받습니다.
<https://github.com/wansucong-stoom/stoom-pwh/releases/download/engine-rhwp-0.8.7-pwh-r2/pwh-upstream-rhwp-0.8.7-1a76570e8339.zip>

보존한 소스 스냅샷에는 참조 문서와 `saved/`가 의도적으로 빠져 있습니다. 라이브러리의 `newBlank` 구현은 컴파일할 때 `saved/blank2010.hwp`를 포함하므로, 재빌드에는 원본 빈 문서 양식이 필요합니다. 고정 커밋의 원본 위치는 다음과 같습니다.
<https://raw.githubusercontent.com/edwardkim/rhwp/1a76570e833917d15817415a53c09ad61ab3203f/saved/blank2010.hwp>

이 파일을 로컬 입력으로 제공하면 스크립트가 복사 전에 해시를 검증합니다. 사용자 문서나 기관 양식은 필요하지 않습니다.

Windows 빌드에는 Rust의 `1.93.1-x86_64-pc-windows-gnu` 도구 체인과 공식 `wasm-bindgen-0.2.127-x86_64-pc-windows-msvc` 실행 파일을 사용했습니다. 도구의 호스트 식별자는 WebAssembly 컴파일 대상을 변경하지 않습니다. 호환되는 도구 체인과 `wasm32-unknown-unknown` 표준 라이브러리가 미리 설치되어 있어야 합니다.

<a id="rebuild-into-a-separate-candidate"></a>
## 별도의 후보 코어로 재빌드

`scripts/build-patched-core.mjs`는 모든 경로를 인수로 받습니다. 유지 관리자의 홈·작업 공간 경로를 사용하거나, 런타임을 설치하거나, 엔진 잠금 파일을 수정하거나, 기존 소스·출력 디렉터리를 덮어쓰지 않습니다. 패치를 적용하기 전에 소스와 패치를 검증하고 예상하지 않은 소스 리비전은 거절합니다. r20 소스는 스물아홉 패치를 기록된 순서대로 적용합니다. r17의 스물여섯 패치와 앞선 런타임 기록은 각 릴리스에 보존합니다. Windows의 전역 `core.autocrlf` 설정이 소스 해시를 바꾸지 않도록 패치를 적용할 때 Git의 줄바꿈 변환을 명시적으로 끕니다.

저장소를 내려받고 필요한 입력과 도구를 로컬에 준비한 뒤 실행하는 예입니다.

```powershell
$env:RUSTUP_TOOLCHAIN = '1.93.1-x86_64-pc-windows-gnu'
node scripts/build-patched-core.mjs `
  --source-archive C:\pwh-inputs\pwh-upstream-rhwp-0.8.7-1a76570e8339.zip `
  --blank-template C:\pwh-inputs\blank2010.hwp `
  --source-root C:\pwh-rebuild\source `
  --output-root C:\pwh-rebuild\candidate-core `
  --wasm-bindgen C:\pwh-tools\wasm-bindgen.exe
```

Node.js 22.12 이상, Python 3.11 이상, Git과 고정된 Rust 도구가 PATH에 있어야 합니다. 또는 `--python`, `--cargo`, `--rustc`, `--wasm-bindgen`으로 경로를 지정할 수 있습니다. `RUSTUP_HOME`과 `CARGO_HOME`은 상속되며 격리된 빌드 환경을 가리킬 수 있습니다. `--target-dir`로 기존 컴파일 캐시를 재사용할 수 있습니다. `--offline`은 Cargo의 의존성 다운로드를 막으므로 필요한 의존성이 이미 있어야 합니다. `--prepare-only`는 컴파일러를 실행하지 않고 소스·해시·패치·작업 공간·양식을 준비합니다. 실행할 때마다 새로운 소스·출력 경로를 선택하세요. 실패한 후보 디렉터리는 삭제하지 않고 검토용으로 보존합니다.

실제 빌드 명령은 다음과 같습니다.

```text
cargo build --lib --target wasm32-unknown-unknown --release
wasm-bindgen --target web --out-name rhwp --out-dir <candidate-core> <target>/wasm32-unknown-unknown/release/rhwp.wasm
```

원본의 기본 기능을 유지하며, 요청한 경우에만 `--offline`을 추가합니다. Cargo 의존성과 Rust·wasm-bindgen 설치 파일은 이 스크립트에 포함되지 않습니다. 따라서 고정된 입력으로 재현하는 절차이며, 모든 도구가 포함된 완전한 오프라인 도구 체인이라는 뜻은 아닙니다.

<a id="workspace-and-dependency-lock-handling"></a>
## 작업 공간과 의존성 잠금 파일 처리

보존된 소스 ZIP에는 원래 작업 공간 목록에 이름이 남아 있는 독립 `tools/` 프로젝트가 없습니다. 스냅샷을 그대로 빌드하면 없는 작업 공간 manifest를 해석하는 과정에서 실패합니다. 이 WASM 라이브러리 빌드에서는 루트 작업 공간의 `members`만 `[".", "crates/*"]`로 제한하고, `default-members`, 루트 의존성 선언 및 각 크레이트 manifest는 유지합니다. 제외되는 구성원은 `tools/rhwp-subsecond`, `bindings/Native`, `tools/batch-convert` 및 세 개의 `tools/llm_verifier` 프로젝트입니다.

첫 빌드는 의도적으로 `--locked`를 사용하지 않습니다. 제외한 작업 공간 구성원에게만 필요한 잠금 항목을 Cargo가 정리해야 하기 때문입니다. 빌드 직후 스크립트는 Python의 TOML 파서로 결과 잠금 파일과 원본 ZIP의 잠금 파일을 비교합니다. 패키지가 추가되거나 유지된 패키지의 전체 잠금 레코드에서 버전, 소스, 체크섬 또는 의존성 목록이 하나라도 달라지면 **후보를 거절합니다**.

검증된 빌드에서는 원래 408개 패키지 레코드가 373개로 정리됐습니다. 35개가 삭제되고, 추가는 0개, 유지된 레코드의 변경도 0개였습니다. 여기에는 로컬 작업 공간 패키지 6개와 더 이상 쓰지 않는 레지스트리 의존성의 제거가 포함됩니다. 유지된 의존성의 버전은 갱신하지 않았습니다. 정리된 `Cargo.lock`의 SHA256은 `775639086168903cd7b5978704decf498aac7235b6a5e89c5a4fe8be325b3b06`입니다. 이 파일은 빌드 작업 공간에서 생성한 결과물이며 원본의 잠금 파일을 대체하지 않습니다.

<a id="output-and-release-boundary"></a>
## 산출물과 배포 범위

스크립트는 생성된 `.wasm`, JavaScript 연결 코드, 타입 선언, 원본 라이선스와 입력·출력 해시, 도구 버전, 잠금 파일 감사 결과가 담긴 `BUILD-RECORD.json`을 출력합니다. r9의 Canvas 상태 복원은 생성된 연결 코드에 `globalAlpha` 읽기를 추가합니다. 빌드 스크립트의 `expectedGlueSha256`은 이 정확한 생성 결과를 고정하며, 공통·Desktop 인라인 편집기도 같은 연결부로 다시 빌드합니다. 보존 스크립트는 호스트 WASM 로더 한 곳만 정규화한 뒤 전체 연결부 해시가 새 코어와 일치하는지 검사합니다. 과거 r8의 연결부와 같다고 표기하지 않습니다.

독립적으로 반복한 **첫 번째 패치만 적용한** 빌드는 13,751,774바이트이고 SHA256은 `2af00b34b622b33d341d0be5a78f00d56dcd50d74fddca1ec71dd5d5474af907`입니다. 이는 행 최소 높이 보완의 과거 검증 기록입니다. 현재 재빌드 스크립트는 스물일곱 패치의 입력·출력 소스 해시를 `BUILD-RECORD.json`에 기록하며, 27번에서 추가한 WASM API와 JavaScript 연결 코드의 해시도 확인합니다.

검증된 **두 패치 운영 빌드**는 13,752,323바이트이고 SHA256은 `a9c082330122e79120f8e0976f94837cc62625261fbb77c2fa2f51d6cb3e09d8`입니다. 그 정확한 산출물에 대해 두 합성 WASM 검사 모음이 모두 통과했습니다. 행 안에 내용이 들어가는지, 저장된 간격 대조군, 표 뒤 텍스트 커서 위치, 연속된 표와 쪽 경계를 포함해 25개 통과, 0개 실패, 0개 건너뜀입니다. 재빌드할 때마다 실제 해시를 기록하고, 컴파일러 경로나 빌드 환경 차이가 생기면 같은 빌드로 임의 표기하지 말고 원인을 확인해야 합니다.

패키징 전에 재빌드한 코어로 합성 회귀 테스트 자료를 실행하세요. 줄바꿈한 NO_LS 행에 내용이 들어가고, 내용이 들어가는 행은 기존 보정을 유지해야 합니다. 내보내고 다시 열었을 때 문서 내용과 원본 셀 높이가 유지되고, 스냅샷 실행 취소로 원래 상태가 복원되어야 합니다. 컴파일 성공이나 패치 해시 확인만으로 렌더링이 검증되는 것은 아닙니다.

인라인 표 간격은 표 높이, 바깥 여백, 속성 켜짐·꺼짐과 퍼센트 설정을 각각 바꿔 비교합니다. 기존 배치가 유지되는지 확인할 수 있도록 100% 대조군과 저장 LINE_SEG 대조군을 포함합니다. 내보내기·다시 열기 후 보존 및 쪽 경계 사례와 함께, 뒤따르는 문단의 표시 위치와 커서 위치를 모두 확인합니다. 공통 줄 상자 계산을 특정 문서에만 맞춘 픽셀 보정으로 대체하지 않습니다.

후보 코어를 지정해 두 검사 모음을 실행합니다.

```powershell
$env:PWH_CORE_JS = 'C:\pwh-rebuild\candidate-core\rhwp.js'
$env:PWH_CORE_WASM = 'C:\pwh-rebuild\candidate-core\rhwp_bg.wasm'
node --test tests/rowbreak-table-height.test.mjs tests/tac-table-line-spacing.test.mjs
```

이 테스트 자료에는 합성 텍스트와 배치 정보만 있습니다. 사용자 문서, 기관 보고서, 원본 문서 경로 또는 연구 원고는 포함하지 않습니다. 두 환경 변수를 모두 지정하지 않으면 코어 의존 검사가 건너뛰어지며, 건너뛴 실행은 후보 엔진을 검증한 것이 아닙니다.

수정한 코어를 배포할 때는 **새로운 불변 엔진 리비전**, 별도의 출처 정보 및 런타임 manifest가 필요합니다. engine-r2와 원래 npm 코어 바이트를 유지하세요. `scripts/preserve-engine.py`가 원래 코어가 바뀌지 않았는지 확인하는 조건을 우회하거나, 변경된 바이트를 기존 식별자로 허용하도록 바꾸면 안 됩니다. 패치한 리비전은 명시적인 배포 절차로 준비·검증합니다. 재빌드 스크립트는 이를 게시하거나 `runtime-lock.json`을 수정하지 않습니다.

<a id="preserve-a-later-patched-runtime"></a>
## 이후 패치 런타임 보존

`scripts/preserve-engine.py`는 원본 바이너리를 보존하며 최초 소스·라이선스 보존에 계속 사용합니다. 패치된 코어를 패키징하기 위해 원래 코어 검사를 약화해서는 안 됩니다.

`scripts/preserve-patched-runtime.py`는 이전 불변 런타임 아카이브와 전체 manifest, 새로 최적화한 코어의 `BUILD-RECORD.json`, 현재 패치의 모든 해시, 버전이 지정된 인라인 클라이언트 파일의 해시를 검증합니다. 인라인 빌드에서 호스트가 제공한 WASM을 찾는 부분도 정규화해 나머지 JavaScript 연결 코드가 재빌드한 코어와 정확히 일치함을 확인합니다. 통과한 회귀 검사 근거는 정확한 WASM 및 빌드 기록 다이제스트를 식별해야 합니다. 스크립트는 새 출력 디렉터리에 새 런타임 ZIP, 소스·빌드 입력 아카이브, 검증 기록 및 제안된 잠금 파일을 생성합니다. 프로젝트의 잠금 파일이나 설치된 런타임에는 쓰지 않습니다.

코어와 인라인 클라이언트 회귀 검사를 완료한 뒤 실행하는 예입니다.

```text
python scripts/preserve-patched-runtime.py --base-lock <preserved-r3-runtime-lock.json> --base-archive <verified-r3.zip> --candidate-core <optimized-core> --client-root client --client-build-root <studio-build-root> --regression-evidence <passing-core-regression.json> --revision 4 --output-dir <new-r4-output>
```

현재 Pwh와 Desktop 인라인 클라이언트는 새로운 공통 코어를 사용합니다. 별도로 보존한 과거 전체 Studio 구성 요소는 기본적으로 이전 바이트를 유지합니다. 묶여 있는 WASM은 ABI가 일치할 것이라는 추측만으로 교체하면 안 됩니다. 전체 교체에는 선택적 `--studio-replacement`와 `--studio-verification` 입력을 통해 명시적인 트리 해시와 스모크 테스트 근거가 필요합니다. 이 적용 범위는 manifest와 검증 파일에 기록합니다. 기존 원본 소스, 의존성 및 라이선스 자산은 변경되지 않는 기존 URL을 유지합니다.
