import { readFile } from 'node:fs/promises';
import { isAbsolute } from 'node:path';
import { pathToFileURL } from 'node:url';

// MCP Apps / OpenAI File Entrypoint contracts:
// https://github.com/openai/mcp-extensions/blob/main/docs/spec.md#file-extension-entrypoint
// https://github.com/modelcontextprotocol/ext-apps/blob/main/specification/2026-01-26/apps.mdx
export const VIEWER_URI = 'ui://pwh/viewer';
const VERSION = '0.3.0';
const MIME = 'text/html;profile=mcp-app';
// Use the established single-result MCP protocol; 2026-07-28 MRTR is not implemented.
const SUPPORTED_PROTOCOLS = ['2024-11-05', '2025-03-26', '2025-06-18', '2025-11-25'];
const objectSchema = (properties = {}, required = []) => ({ type: 'object', properties, required, additionalProperties: false });
const pathSchema = { type: 'string', minLength: 1, description: '실행 호스트의 절대 파일 경로' };
const outputSchema = { ...pathSchema, description: '새 출력 문서의 절대 경로. 생략하면 엔진의 기본 출력 폴더에 고유한 파일명으로 저장합니다. 기존 파일은 덮어쓰지 않습니다.' };
const documentSpecSchema = {
  type: 'object', required: ['version', 'blocks'], additionalProperties: true,
  description: 'rhwp scaffold 명세. 예: {"version":"1","title":"보고서","font":"맑은 고딕","blocks":[{"type":"heading","level":1,"text":"보고서"},{"type":"paragraph","text":"본문"},{"type":"table","rows":[["항목","내용"],["상태","완료"]]}]}',
  properties: {
    version: { type: 'string', const: '1', description: '명세 버전: "1"' },
    title: { type: 'string', description: '문서 제목' },
    font: { type: 'string', minLength: 1, description: '사용할 글꼴 이름. 예: 맑은 고딕' },
    blocks: {
      type: 'array', minItems: 1,
      description: '순서대로 배치할 문서 블록. paragraph는 text, heading은 level/text, table은 rows(문자열 셀의 2차원 배열)를 사용합니다. 추가 서식 속성은 rhwp 명세에 따릅니다.',
      items: { type: 'object', properties: { type: { type: 'string', minLength: 1 } }, required: ['type'], additionalProperties: true },
    },
  },
};
const previewProperties = {
  outputDir: { type: 'string', minLength: 1, description: '미리보기 출력 폴더의 절대 경로. 생략하면 임시 폴더를 사용합니다.' },
  pages: { type: 'array', items: { type: 'integer', minimum: 1 }, minItems: 1, maxItems: 24, uniqueItems: true, description: '표시할 쪽 번호. 1부터 시작하며 생략하면 첫 최대 8쪽입니다. 최대 24쪽씩 요청하세요.' },
  maxDimension: { type: 'integer', minimum: 400, maximum: 2400, description: '쪽 이미지의 긴 변 최대 픽셀 수' },
};
const readOnly = { readOnlyHint: true, destructiveHint: false, openWorldHint: false };
const writeDocument = { readOnlyHint: false, destructiveHint: false, openWorldHint: false };
const viewerMeta = { ui: { resourceUri: VIEWER_URI } };
const liveExpectedStateSchema = {
  type: 'object',
  properties: {
    documentEpoch: { type: 'integer', minimum: 0 },
    changeSeq: { type: 'integer', minimum: 0 },
    documentSha256: { type: 'string', minLength: 64 },
  },
  required: ['documentEpoch', 'changeSeq', 'documentSha256'],
  additionalProperties: true,
  description: '직전 pwh_live_read가 반환한 state. 사용자 편집 이후 오래된 상태로 수정하거나 저장하지 않도록 같은 epoch/changeSeq/SHA를 확인합니다.',
};
const liveOperationSchema = {
  oneOf: [
    objectSchema({
      type: { const: 'command' },
      id: { type: 'string', minLength: 1, description: 'pwh_live_commands가 반환한 실제 Studio 명령 ID' },
      params: { type: 'object', additionalProperties: true },
    }, ['type', 'id']),
    objectSchema({
      type: { const: 'hwpctrl' },
      calls: {
        type: 'array', minItems: 1, maxItems: 100,
        items: objectSchema({
          method: { type: 'string', minLength: 1 },
          args: { type: 'array', items: {} },
        }, ['method', 'args']),
      },
    }, ['type', 'calls']),
    objectSchema({
      type: { const: 'applyTextCommand' },
      command: { type: 'object', additionalProperties: true, description: '현재 Studio가 지원하는 exact text command v1 명세' },
    }, ['type', 'command']),
    objectSchema({ type: { const: 'undo' } }, ['type']),
    objectSchema({ type: { const: 'redo' } }, ['type']),
  ],
};

export const TOOLS = [
  {
    name: 'pwh_live_request', title: '선택한 문서 객체와 수정 요청 읽기',
    description: 'AI 수정 요청 주석의 requestId로 선택한 글자·문단·표 셀·서식과 해당 문서 버전을 읽습니다. 수정 전 현재 pwh_live_read 상태와 대조하세요.',
    inputSchema: objectSchema({ requestId: {type:'string',minLength:36} }, ['requestId']), annotations: readOnly,
  },
  {
    name: 'pwh_live_open', title: '한글 문서 함께 편집',
    description: '실제 rhwp Studio 편집 화면을 로컬 브라우저 URL로 엽니다. 사용자와 에이전트가 같은 메모리 문서를 편집합니다. input을 생략하면 현재 세션을 사용하거나 빈 문서를 엽니다. 반환된 URL을 브라우저 패널에서 여세요.',
    inputSchema: objectSchema({ input: pathSchema }), annotations: writeDocument,
  },
  {
    name: 'pwh_live_read', title: '현재 편집 문서 읽기',
    description: '브라우저의 현재 편집 세션에서 최신 문서 상태·선택·텍스트를 읽습니다. 디스크 저장본과 다른 미저장 사용자 편집도 포함합니다. 반환한 state를 수정·저장 시 expectedState로 전달하세요.',
    inputSchema: objectSchema({diagnostics:{type:'boolean',description:'실제 렌더러와 글꼴 선택 진단도 읽습니다.'},page:{type:'integer',minimum:0,description:'진단할 쪽. 0부터 시작합니다.'}}), annotations: readOnly,
  },
  {
    name: 'pwh_live_commands', title: '현재 편집기 명령 조회',
    description: '열린 Studio 편집기가 실제 제공하는 메뉴·서식 명령과 실행 상태를 조회합니다. 실행할 ID는 이 결과에서 선택하세요.',
    inputSchema: objectSchema(), annotations: readOnly,
  },
  {
    name: 'pwh_live_apply', title: '현재 문서 함께 수정',
    description: '사용자가 보고 편집하는 현재 Studio 문서에 명령·HwpCtrl 배치·exact text command·되돌리기를 적용합니다. 최신 pwh_live_read의 expectedState가 필수이며 상태가 바뀌면 다시 읽어야 합니다. 디스크 파일 편집 도구와 달리 현재 화면에 반영됩니다.',
    inputSchema: objectSchema({ operation: liveOperationSchema, expectedState: liveExpectedStateSchema }, ['operation', 'expectedState']),
    annotations: writeDocument,
  },
  {
    name: 'pwh_live_save', title: '현재 편집 문서 저장',
    description: '브라우저에서 사용자와 에이전트가 편집한 현재 문서를 새 HWP/HWPX 파일로 저장합니다. 원본과 기존 파일을 덮어쓰지 않습니다. 최신 pwh_live_read의 expectedState가 필수입니다.',
    inputSchema: objectSchema({ output: outputSchema, expectedState: liveExpectedStateSchema }, ['expectedState']),
    annotations: writeDocument,
  },
  {
    name: 'pwh_live_status', title: '공유 편집 세션 상태',
    description: '현재 실제 편집 화면의 URL·세션 ID·원본·브라우저 연결 상태를 확인합니다. 문서의 최신 내용은 pwh_live_read로 읽으세요.',
    inputSchema: objectSchema(), annotations: readOnly,
  },
  {
    name: 'pwh_status', title: 'pwh 조판 엔진 상태',
    description: 'pwh가 사용하는 로컬 rhwp 조판 엔진의 상태와 버전을 확인합니다.',
    inputSchema: objectSchema(), annotations: readOnly,
  },
  {
    name: 'pwh_info', title: 'HWPX 문서 정보',
    description: '디스크에 저장된 HWP/HWPX 문서의 문단·표 등 구조와 정보를 확인합니다. 현재 브라우저의 미저장 편집은 pwh_live_read로 확인하세요.',
    inputSchema: objectSchema({ input: pathSchema }, ['input']), annotations: readOnly,
  },
  {
    name: 'pwh_template_inspect', title: '기관 HWPX 양식 구조·서식 분석',
    description: '저장된 HWPX의 글자·문단 서식 ID, 이름 있는 스타일, 용지 여백, 중첩 표·병합 셀, 배치 정보를 읽습니다. 먼저 summary를 읽고 필요한 원본 문단이나 서식만 상세 조회하세요. XML 문단 ID와 편집 인덱스는 다르며, 저장된 줄 좌표가 재조판 결과를 보장하지 않습니다. 원본은 변경하지 않습니다.',
    inputSchema: objectSchema({
      input: pathSchema,
      detail: { type: 'string', enum: ['summary', 'paragraph', 'format'], default: 'summary' },
      sectionIndex: { type: 'integer', minimum: 0, description: 'summary가 반환한 0부터 시작하는 구역 인덱스' },
      topParagraphIndex: { type: 'integer', minimum: 0, description: 'paragraph 조회 대상의 원본 본문 문단 인덱스' },
      tablePath: { type: 'array', minItems: 1, maxItems: 8, items: { oneOf: [
        { type: 'integer', minimum: 0 },
        { type: 'object', properties: { tableOrdinal: {type:'integer',minimum:0}, cellAddr: {type:'object',additionalProperties:true} }, required: ['tableOrdinal'], additionalProperties:true },
      ] }, description: '분석이 반환한 중첩 표 경로 또는 tableOrdinal 배열' },
      recordType: { type: 'string', enum: ['charPr', 'paraPr', 'styles'] },
      id: { type: 'string', minLength: 1, description: 'format 조회 대상의 원본 서식 ID' },
    }, ['input']), annotations: readOnly,
  },
  {
    name: 'pwh_create_document', title: 'HWPX 문서 만들기',
    description: '제목·문단·표 등을 담은 spec으로 새 HWPX 문서를 만듭니다. 완료 후 pwh_preview로 조판 결과를 확인하세요.',
    inputSchema: objectSchema({ spec: documentSpecSchema, output: outputSchema }, ['spec']),
    annotations: writeDocument,
  },
  {
    name: 'pwh_fill_form', title: '기관 양식의 문단·셀 채우기',
    description: 'pwh_template_inspect로 이해한 기관 양식의 평문 문단·표 셀을 원본 XML 주소로 채우고 새 HWPX를 만듭니다. 구역·단·쪽 나눔·표 앵커·셀 병합·배치와 기존 서식 정의를 보존합니다. 조판 개체가 들어 있는 문단·셀의 평문화는 거절합니다. 원본 SHA256과 현재 텍스트를 대조하고, 이후 조판 결과를 반드시 검수하세요.',
    inputSchema: objectSchema({
      input:pathSchema,output:outputSchema,
      expectedSourceSha256:{type:'string',minLength:64},
      dropSavedLineSegments:{type:'boolean',description:'저장 당시 줄 배치 캐시를 지워 엔진의 재조판을 사용합니다.'},
      edits:{type:'array',minItems:1,maxItems:256,items:objectSchema({
        xmlPath:{type:'string',minLength:1,description:'분석이 반환한 /sec/p[n]/…/p[n], /tc[n], 또는 /run[n]/t[n] 주소. 0부터 시작합니다. 조판 개체가 있는 문단에서는 안전한 t 말단만 수정하세요.'},
        sectionIndex:{type:'integer',minimum:0},
        expectedText:{type:'string',description:'수정 전 텍스트. 셀의 여러 문단은 줄바꿈으로 연결합니다.'},
        text:{type:'string'},paragraphs:{type:'array',minItems:1,maxItems:100,items:{type:'string'}},
        charPrIDRef:{type:'string',minLength:1,description:'선택적으로 적용할 기존 글자 서식 ID'},
        textColor:{type:'string',minLength:7,description:'예: #000000. 원본 글자 서식을 복제해 색만 바꿉니다.'},
      },['xmlPath'])},
    },['input','expectedSourceSha256','edits']),annotations:writeDocument,
  },
  {
    name: 'pwh_replace_image', title: '기존 그림을 새 이미지로 교체',
    description: '저장된 HWPX의 기존 BinData 그림을 로컬 PNG·JPEG·BMP 이미지로 교체한 새 파일을 만듭니다. AI가 별도로 생성한 이미지도 image 경로로 받을 수 있습니다. 기존 그림과 같은 파일 형식만 허용하며 앵커·크기·자르기·회전·배치 XML과 나머지 ZIP 항목은 보존합니다. 같은 BinData를 참조한 모든 그림이 함께 바뀝니다. 비율이 다르면 기존 틀에서 왜곡·잘림이 생길 수 있으므로 새 파일을 재조판해 확인하세요. 원본과 기존 출력은 덮어쓰지 않습니다.',
    inputSchema: objectSchema({
      input: pathSchema, output: {...pathSchema, description: '반드시 새 HWPX의 절대 경로를 지정합니다. 기존 파일은 덮어쓰지 않습니다.'},
      image: {...pathSchema, description: '교체할 로컬 이미지 절대 경로. 정적 PNG, 8-bit JPEG, 비압축/bitfield Windows BMP. 형식 변환은 하지 않습니다.'},
      expectedSourceSha256: {type: 'string', minLength: 64, maxLength: 64},
      binaryItemId: {type: 'string', minLength: 1, description: 'Contents/content.hpf의 기존 그림 manifest item ID. manifestHref와 둘 중 하나만 지정합니다.'},
      manifestHref: {type: 'string', minLength: 1, description: 'Contents/content.hpf의 기존 그림 item href 원문. binaryItemId와 둘 중 하나만 지정합니다.'},
    }, ['input', 'output', 'image', 'expectedSourceSha256']), annotations: writeDocument,
  },
  {
    name: 'pwh_edit_template', title: 'HWPX 서식 채우기',
    description: '디스크의 기존 HWPX에서 텍스트 치환, 필드 채우기, 표 셀 수정을 적용한 새 문서를 저장합니다. table·row·col은 0부터 시작합니다. 현재 브라우저 편집 세션을 수정하려면 pwh_live_apply를 사용하세요.',
    inputSchema: objectSchema({
      input: pathSchema, output: outputSchema,
      changes: {
        type: 'array', minItems: 1, maxItems: 100,
        items: { oneOf: [
          objectSchema({ type: { const: 'replaceText' }, find: { type: 'string', minLength: 1 }, replace: { type: 'string' } }, ['type', 'find', 'replace']),
          objectSchema({ type: { const: 'fillFields' }, data: { type: 'object', additionalProperties: true } }, ['type', 'data']),
          objectSchema({ type: { const: 'setCell' }, table: { type: 'integer', minimum: 0 }, row: { type: 'integer', minimum: 0 }, col: { type: 'integer', minimum: 0 }, text: { type: 'string' } }, ['type', 'table', 'row', 'col', 'text']),
        ] },
      },
    }, ['input', 'changes']),
    annotations: writeDocument,
  },
  {
    name: 'pwh_preview', title: 'HWPX 쪽 미리보기',
    description: 'HWP/HWPX를 조판해 쪽별 PNG와 HTML 미리보기를 만듭니다. 채팅 이미지와 문서 뷰어에 같은 조판 결과를 제공합니다.',
    inputSchema: objectSchema({ input: pathSchema, ...previewProperties }, ['input']),
    annotations: readOnly, _meta: viewerMeta,
  },
  {
    name: 'pwh_open', title: 'pwh 문서 뷰어',
    description: '호스트에서 선택한 HWP/HWPX를 문서 패널에서 엽니다. file.resourceUri는 호스트가 제공하는 불투명 URI입니다.',
    inputSchema: objectSchema({ file: objectSchema({ name: { type: 'string', minLength: 1 }, resourceUri: { type: 'string', minLength: 1 } }, ['name', 'resourceUri']) }, ['file']),
    annotations: readOnly,
    _meta: { ...viewerMeta, 'openai/ui': { entrypoints: [{ type: 'file', extensions: ['.hwpx', '.hwp'] }] } },
  },
  {
    name: 'pwh_render_open_file', title: '열린 문서 조판',
    description: '파일 뷰어 전용입니다. 호스트가 요청 메타에 제공한 열린 파일 경로만 조판합니다.',
    inputSchema: objectSchema({ pages: previewProperties.pages, maxDimension: previewProperties.maxDimension }),
    annotations: readOnly, _meta: { ui: { visibility: ['app'] } },
  },
];

class RpcError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

let enginePromise;
function loadEngine() {
  // Keep discovery and the static viewer available while the engine is being built.
  if (!enginePromise) enginePromise = import('./engine.mjs').catch((error) => { enginePromise = undefined; throw error; });
  return enginePromise;
}
let livePromise;
function loadLive() {
  if (!livePromise) livePromise = import('./live.mjs').catch((error) => { livePromise = undefined; throw error; });
  return livePromise;
}

function validate(schema, value, location = 'arguments') {
  if (schema.oneOf) {
    for (const option of schema.oneOf) {
      try { validate(option, value, location); return; } catch { /* Try the next operation schema. */ }
    }
    throw new RpcError(-32602, `${location}: 지원하는 변경 작업 형식이 아닙니다.`);
  }
  if ('const' in schema && value !== schema.const) throw new RpcError(-32602, `${location}: 값이 올바르지 않습니다.`);
  if (schema.type === 'object') {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new RpcError(-32602, `${location}: 객체가 필요합니다.`);
    for (const key of schema.required ?? []) if (!(key in value)) throw new RpcError(-32602, `${location}.${key}: 필수 값입니다.`);
    for (const [key, item] of Object.entries(value)) {
      if (Object.hasOwn(schema.properties ?? {}, key)) validate(schema.properties[key], item, `${location}.${key}`);
      else if (schema.additionalProperties === false) throw new RpcError(-32602, `${location}.${key}: 알 수 없는 값입니다.`);
    }
  } else if (schema.type === 'array') {
    if (!Array.isArray(value) || value.length < (schema.minItems ?? 0)) throw new RpcError(-32602, `${location}: 비어 있지 않은 배열이 필요합니다.`);
    if (value.length > (schema.maxItems ?? Infinity)) throw new RpcError(-32602, `${location}: 최대 ${schema.maxItems}개까지 허용합니다.`);
    if (schema.uniqueItems && new Set(value).size !== value.length) throw new RpcError(-32602, `${location}: 중복 값은 허용하지 않습니다.`);
    value.forEach((item, index) => validate(schema.items, item, `${location}[${index}]`));
  } else if (schema.type === 'string') {
    if (typeof value !== 'string' || value.length < (schema.minLength ?? 0)) throw new RpcError(-32602, `${location}: 올바른 문자열이 필요합니다.`);
  } else if (schema.type === 'integer') {
    if (!Number.isInteger(value) || value < (schema.minimum ?? -Infinity) || value > (schema.maximum ?? Infinity)) throw new RpcError(-32602, `${location}: 허용 범위의 정수가 필요합니다.`);
  }
}

function absolutePath(value, name) {
  if (typeof value !== 'string' || !isAbsolute(value) || value.includes('\0')) throw new RpcError(-32602, `${name}: 절대 경로가 필요합니다.`);
  return value;
}

const textResult = (value, summary) => ({ content: [{ type: 'text', text: summary ?? JSON.stringify(value, null, 2) }], structuredContent: value });

async function previewResult(input, options, { includeImages = true } = {}) {
  const engine = await loadEngine();
  const preview = await engine.previewDocument(input, options);
  if (!preview || !Array.isArray(preview.pages)) throw new Error('조판 엔진이 올바른 쪽 목록을 반환하지 않았습니다.');
  const images = preview.pages.map((page) => {
    const match = /^data:image\/png;base64,([A-Za-z0-9+/=\r\n]+)$/.exec(page.dataUrl ?? '');
    if (!match) throw new Error(`${page.pageNumber ?? '?'}쪽 PNG 이미지가 올바르지 않습니다.`);
    return { type: 'image', mimeType: 'image/png', data: match[1].replace(/[\r\n]/g, '') };
  });
  const shown = preview.pages.map((page) => page.pageNumber).join(', ');
  // Structured content enters model context. Keep bitmap bytes in image content and UI-only metadata.
  const summary = { ...preview, pages: preview.pages.map(({ dataUrl, ...page }) => page) };
  return {
    content: [
      { type: 'text', text: `${preview.title || '문서'} · 전체 ${preview.pageCount}쪽 · 미리보기 ${shown || '없음'}쪽${preview.htmlPath ? `\nHTML: ${preview.htmlPath}` : ''}` },
      ...(includeImages ? images : []),
    ],
    structuredContent: summary,
    _meta: { ...viewerMeta, 'pwh/preview': preview },
  };
}

export async function callTool(name, args = {}, requestMeta = {}) {
  // Accept old local development calls without advertising a second service name.
  if (name.startsWith('hop_')) name = `pwh_${name.slice(4)}`;
  const definition = TOOLS.find((tool) => tool.name === name);
  if (!definition) throw new RpcError(-32602, `알 수 없는 도구: ${name}`);
  validate(definition.inputSchema, args);
  if (name === 'pwh_live_request') return textResult(await (await loadLive()).readLiveRequest(args.requestId));
  if (name.startsWith('pwh_live_')) {
    const live = await loadLive();
    if (name === 'pwh_live_open') return textResult(await live.openLiveDocument(args.input === undefined ? undefined : absolutePath(args.input, 'input')));
    if (name === 'pwh_live_read') return textResult(await live.readLiveSession(args));
    if (name === 'pwh_live_commands') return textResult({ commands: await live.listLiveCommands() });
    if (name === 'pwh_live_apply') return textResult(await live.applyLiveSession(args.operation, args.expectedState));
    if (name === 'pwh_live_save') return textResult(await live.saveLiveSession(args.output === undefined ? undefined : absolutePath(args.output, 'output'), args.expectedState));
    if (name === 'pwh_live_status') return textResult(await live.describeLiveSession());
  }
  if (name === 'pwh_open') return textResult({ file: args.file, title: args.file.name, awaitingRender: true }, `${args.file.name} 문서 뷰어를 엽니다.`);
  if (name === 'pwh_render_open_file') {
    // Never accept a raw path supplied by iframe arguments. This field is host-injected.
    const openedPath = requestMeta?.['openai/resource']?.path;
    if (typeof openedPath !== 'string' || !isAbsolute(openedPath)) throw new Error('호스트가 열린 문서 경로를 제공하지 않았습니다. HWP/HWPX 파일의 문서 뷰어에서 다시 열어 주세요.');
    return previewResult(absolutePath(openedPath, '열린 문서'), args, { includeImages: false });
  }
  if (name === 'pwh_template_inspect') {
    const {input, ...options} = args;
    return textResult(await (await import('./template.mjs')).inspectTemplate(absolutePath(input, 'input'), options));
  }
  if (name === 'pwh_fill_form') return textResult(await (await import('./form.mjs')).fillInstitutionForm(args));
  if (name === 'pwh_replace_image') return textResult(await (await import('./images.mjs')).replaceDocumentImage(args));
  const engine = await loadEngine();
  if (name === 'pwh_status') return textResult(await engine.engineInfo());
  if (name === 'pwh_info') return textResult(await engine.inspectDocument(absolutePath(args.input, 'input')));
  if (name === 'pwh_create_document') return textResult(await engine.createDocument(args.spec, args.output === undefined ? undefined : absolutePath(args.output, 'output')));
  if (name === 'pwh_edit_template') return textResult(await engine.editTemplate(absolutePath(args.input, 'input'), args.output === undefined ? undefined : absolutePath(args.output, 'output'), args.changes));
  if (name === 'pwh_preview') {
    const { input, ...options } = args;
    if (options.outputDir) absolutePath(options.outputDir, 'outputDir');
    return previewResult(absolutePath(input, 'input'), options);
  }
  throw new RpcError(-32602, `지원하지 않는 도구: ${name}`);
}

export async function handleRequest(message) {
  const validObject = message && typeof message === 'object' && !Array.isArray(message);
  const hasId = validObject && Object.hasOwn(message, 'id');
  const id = hasId && (typeof message.id === 'string' || typeof message.id === 'number' || message.id === null) ? message.id : null;
  if (!validObject || message.jsonrpc !== '2.0' || typeof message.method !== 'string' || (hasId && id === null && message.id !== null)) {
    return { jsonrpc: '2.0', id, error: { code: -32600, message: 'Invalid JSON-RPC request' } };
  }
  if (!hasId) return undefined;
  try {
    const params = message.params ?? {};
    if (!params || typeof params !== 'object' || Array.isArray(params)) throw new RpcError(-32602, 'params must be an object');
    let result;
    switch (message.method) {
      case 'initialize':
        result = {
          protocolVersion: SUPPORTED_PROTOCOLS.includes(params.protocolVersion) ? params.protocolVersion : '2025-11-25',
          capabilities: { tools: { listChanged: false }, resources: { subscribe: false, listChanged: false } },
          serverInfo: { name: 'pwh', version: VERSION, title: 'pwh' },
          instructions: '함께 편집하려면 pwh_live_open의 URL을 브라우저 패널에 열고 pwh_live_read로 현재 문서를 읽으세요. pwh_live_apply와 pwh_live_save에는 최신 expectedState가 필요합니다. pwh_info·pwh_edit_template·pwh_preview는 디스크 파일을 처리하며 브라우저의 미저장 편집과 구분해야 합니다.',
        };
        break;
      case 'server/discover':
        result = {
          resultType: 'complete', supportedVersions: ['2025-11-25'],
          capabilities: { tools: {}, resources: {} },
          _meta: { 'io.modelcontextprotocol/serverInfo': { name: 'pwh', version: VERSION } },
        };
        break;
      case 'ping': result = {}; break;
      case 'tools/list': result = { tools: TOOLS }; break;
      case 'tools/call':
        if (typeof params.name !== 'string') throw new RpcError(-32602, 'name is required');
        try { result = await callTool(params.name, params.arguments ?? {}, params._meta ?? {}); }
        catch (error) {
          if (error instanceof RpcError) throw error;
          result = { isError: true, content: [{ type: 'text', text: error instanceof Error ? error.message : '문서 작업에 실패했습니다.' }] };
        }
        break;
      case 'resources/list': result = { resources: [{ uri: VIEWER_URI, name: 'pwh-viewer', title: 'pwh 문서 뷰어', mimeType: MIME }] }; break;
      case 'resources/templates/list': result = { resourceTemplates: [] }; break;
      case 'resources/read':
        if (params.uri !== VIEWER_URI) throw new RpcError(-32602, 'Unknown resource URI');
        result = { contents: [{
          uri: VIEWER_URI, mimeType: MIME, text: await readFile(new URL('./viewer.html', import.meta.url), 'utf8'),
          _meta: {
            ui: { prefersBorder: true, csp: { connectDomains: [], resourceDomains: [], frameDomains: [] } },
            'openai/ui': { preferredDisplayMode: 'fullscreen', availableDisplayModes: ['inline', 'fullscreen'] },
          },
        }] };
        break;
      default: throw new RpcError(-32601, `Method not found: ${message.method}`);
    }
    return { jsonrpc: '2.0', id, result };
  } catch (error) {
    return { jsonrpc: '2.0', id, error: { code: error instanceof RpcError ? error.code : -32603, message: error instanceof Error ? error.message : 'Internal error' } };
  }
}

export function runStdio(input = process.stdin, output = process.stdout) {
  const MAX_LINE = 16 * 1024 * 1024;
  let buffer = '';
  let discardLine = false;
  let queue = Promise.resolve();
  const send = (message) => new Promise((resolve, reject) => output.write(`${JSON.stringify(message)}\n`, (error) => error ? reject(error) : resolve()));
  const enqueue = (line) => {
    if (!line.trim()) return;
    queue = queue.then(async () => {
      let request;
      try { request = JSON.parse(line); }
      catch { await send({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } }); return; }
      const response = await handleRequest(request);
      if (response) await send(response);
    }).catch((error) => { process.stderr.write(`pwh MCP transport: ${error.message}\n`); });
  };
  input.setEncoding('utf8');
  input.on('data', (chunk) => {
    for (const part of chunk.split(/(?<=\n)/)) {
      const ended = part.endsWith('\n');
      if (!discardLine) buffer += part;
      if (buffer.length > MAX_LINE) {
        buffer = ''; discardLine = true;
        queue = queue.then(() => send({ jsonrpc: '2.0', id: null, error: { code: -32600, message: 'Request exceeds 16 MiB limit' } })).catch(() => {});
      }
      if (ended) {
        if (!discardLine) enqueue(buffer);
        buffer = ''; discardLine = false;
      }
    }
  });
  input.on('end', () => { if (buffer.trim() && !discardLine) enqueue(buffer); });
  input.on('error', (error) => { process.stderr.write(`pwh MCP input: ${error.message}\n`); });
  return { done: () => queue };
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) runStdio();
